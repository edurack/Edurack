// PYQ practice: browse every Previous Year Question by Subject → Chapter →
// Topic and practise it with instant feedback.
//
// Rules this file enforces:
//  • Only questions flagged isPYQ AND belonging to one of OUR batches are
//    served. Mentor batch series (kind "mentorBatchSeries") are mentors' paid
//    content and are never exposed here.
//  • The list endpoint never returns correctOption / correctAnswer / solution.
//    Those come back only from submitPyqAnswer, after the student has tried
//    (or explicitly chosen "show solution"), so the bank can't be scraped
//    from the network tab in one request.
//  • Progress lives in its own collection (practiceProgress) and never touches
//    testAttempts, leaderboards or ranks.
import { createServerFn } from "@tanstack/react-start";
import { adminAuth } from "@/lib/firebase-admin";
import { getDb } from "@/lib/mongo";
import {
  QUESTION_PROJECTION,
  assembleTree,
  buildQuestions,
  chapterOr,
  eligibleBundleIds,
  ensureProgressIndexes,
  ensureQuestionIndexes,
  examForAttempt,
  keyExpr,
  loadOwnedAttempt,
  loadTreeRows,
  practiceKeysFor,
  pyqMatch,
  resolveExam,
  weakChapterAvailability,
  statusOf,
} from "@/lib/pyq-server";
import { loadAttemptTopicAnalysis } from "@/lib/attempt-topics";
import { recordPracticeOutcomes } from "@/lib/practice-progress";
import { pickWeakQuestions, weakKey } from "@/lib/pyq-weak";
import {
  GENERAL_TOPIC,
  UNTAGGED_CHAPTER,
  type Difficulty,
  type OptionKey,
  type PyqAnswer,
  type PyqCheckResult,
  type PyqList,
  type PyqTree,
  type WeakPyqSummary,
} from "@/lib/pyq-types";

const MAX_LIST = 300;
const OPTION_KEYS: OptionKey[] = ["A", "B", "C", "D"];

async function requireSignedIn(token: string) {
  return adminAuth.verifyIdToken(token);
}

// ─── Browse tree with this student's progress ──────────────────────────────
export const getPyqTree = createServerFn({ method: "GET" })
  .validator((data: { token: string; exam?: string }) => data)
  .handler(async ({ data }): Promise<PyqTree> => {
    const decoded = await requireSignedIn(data.token);
    const db = await getDb();
    await ensureProgressIndexes(db);
    await ensureQuestionIndexes(db);
    const exam = await resolveExam(db, decoded.uid, data.exam);
    const rows = await loadTreeRows(db, exam);

    // Per-student progress (never cached).
    const prog = await db
      .collection("practiceProgress")
      .aggregate([
        { $match: { uid: decoded.uid, ...(exam ? { $or: [{ exam }, { exam: { $exists: false } }] } : {}) } },
        {
          $group: {
            _id: { subject: "$subject", chapterKey: "$chapterKey", topicKey: "$topicKey" },
            attempted: { $sum: { $cond: [{ $gt: ["$attempts", 0] }, 1, 0] } },
            correct: { $sum: { $cond: ["$correct", 1, 0] } },
          },
        },
      ])
      .toArray();
    const progMap = new Map(
      prog.map((p) => [`${p._id.subject}|${p._id.chapterKey}|${p._id.topicKey}`, { attempted: p.attempted as number, correct: p.correct as number }]),
    );

    return assembleTree(rows, progMap, exam);
  });

// ─── Resolve "JEE Mains 2022 29 June Shift 2" for a set of questions ───────
// ─── Questions for a chapter / topic (no answers, no solutions) ────────────
export const listPyqQuestions = createServerFn({ method: "GET" })
  .validator(
    (data: {
      token: string;
      subject: string;
      chapter: string;
      topic?: string;
      difficulty?: Difficulty;
      exam?: string;
    }) => data,
  )
  .handler(async ({ data }): Promise<PyqList> => {
    const decoded = await requireSignedIn(data.token);
    const db = await getDb();
    await ensureQuestionIndexes(db);
    const exam = await resolveExam(db, decoded.uid, data.exam);

    const and: Record<string, unknown>[] = [
      { $expr: { $eq: [keyExpr("chapter", UNTAGGED_CHAPTER), data.chapter.trim().toLowerCase()] } },
    ];
    if (data.topic) and.push({ $expr: { $eq: [keyExpr("topic", GENERAL_TOPIC), data.topic.trim().toLowerCase()] } });
    const match: Record<string, unknown> = { ...(await pyqMatch(db, exam)), subject: data.subject, $and: and };
    if (data.difficulty) match.difficulty = data.difficulty;

    const docs = await db
      .collection("questions")
      .find(match, { projection: QUESTION_PROJECTION })
      .sort({ _id: 1 })
      .limit(1000)
      .toArray();

    let questions = await buildQuestions(db, decoded.uid, docs);

    // "year" and "status" (the paper-year and solved/wrong chips) don't change
    // this match at all — they're applied client-side instead, so flipping them
    // doesn't trigger a brand-new (and expensive) fetch. See pyq-practice.tsx.
    const years = [...new Set(questions.map((q) => q.source.year).filter((y): y is string => !!y))].sort((a, b) => b.localeCompare(a));

    // Newest paper first; stable within a paper.
    questions = questions
      .map((q, i) => ({ q, i }))
      .sort((a, b) => (b.q.source.year ?? "").localeCompare(a.q.source.year ?? "") || a.i - b.i)
      .map((x) => x.q);

    return { questions: questions.slice(0, MAX_LIST), years, total: questions.length };
  });

// ─── Check an answer (or reveal the solution) and save progress ────────────
export const submitPyqAnswer = createServerFn({ method: "POST" })
  .validator((data: { token: string; questionId: string; answer: PyqAnswer }) => data)
  .handler(async ({ data }): Promise<PyqCheckResult> => {
    const decoded = await requireSignedIn(data.token);
    const { ObjectId } = await import("mongodb");
    const db = await getDb();
    await ensureProgressIndexes(db);

    if (!/^[a-f0-9]{24}$/i.test(data.questionId)) throw new Error("Question not found.");
    const q = await db.collection("questions").findOne({ _id: new ObjectId(data.questionId) });
    // Same gate as the list: PYQ in one of OUR batches. Without it this endpoint
    // would hand out answers/solutions for paid, non-PYQ questions.
    if (!q || q.isPYQ !== true || !(await eligibleBundleIds(db)).includes(String(q.bundleId))) {
      throw new Error("Question not found.");
    }

    const keys = await practiceKeysFor(db, q);
    const col = db.collection("practiceProgress");
    const where = { uid: decoded.uid, questionId: data.questionId };

    const reveal: Pick<PyqCheckResult, "correctOption" | "correctAnswer" | "solution"> = {
      ...(q.type === "mcq" ? { correctOption: q.correctOption as OptionKey } : { correctAnswer: q.correctAnswer as number }),
      solution: (q.solution as string) ?? "",
    };

    // "Show solution" without answering: scheduled for revision, but not a practice day.
    if (data.answer === null) {
      await recordPracticeOutcomes(db, decoded.uid, [{ questionId: data.questionId, outcome: "revealed", keys }]);
      return { isCorrect: false, revealed: true, ...reveal, status: statusOf(await col.findOne(where)) };
    }

    let isCorrect = false;
    let lastAnswer: string | number;
    if (q.type === "mcq") {
      const opt = data.answer.option;
      if (!opt || !OPTION_KEYS.includes(opt)) throw new Error("Pick an option first.");
      isCorrect = opt === q.correctOption;
      lastAnswer = opt;
    } else {
      const v = data.answer.value;
      if (typeof v !== "number" || !Number.isFinite(v)) throw new Error("Enter a number first.");
      isCorrect = Math.abs(v - (q.correctAnswer as number)) < 1e-6; // same tolerance as the test engine
      lastAnswer = v;
    }

    const rec = await recordPracticeOutcomes(db, decoded.uid, [
      { questionId: data.questionId, outcome: isCorrect ? "correct" : "wrong", lastAnswer, keys },
    ]);
    return {
      isCorrect,
      revealed: false,
      ...reveal,
      status: statusOf(await col.findOne(where)),
      streak: rec ? { current: rec.streak.current, increased: rec.streakIncreased } : undefined,
    };
  });

// ─── "Practice my weak topics" ─────────────────────────────────────────────
// Turns the chapters that cost a student marks in one attempt into a PYQ
// practice session. Weak chapters are derived server-side from the attempt
// itself (the client only sends the attempt id), so the result page and the
// session always agree, and a student can't ask for someone else's.

// How many PYQs can the student practise for each weak chapter? (Drives the buttons on the result page.)
export const getWeakPyqSummary = createServerFn({ method: "GET" })
  .validator((data: { token: string; attemptId: string }) => data)
  .handler(async ({ data }): Promise<WeakPyqSummary> => {
    const decoded = await requireSignedIn(data.token);
    const db = await getDb();
    const attempt = await loadOwnedAttempt(db, decoded.uid, data.attemptId);
    const { focus } = await loadAttemptTopicAnalysis(db, attempt);
    const exam = await examForAttempt(db, decoded.uid, attempt);
    if (focus.length === 0) return { exam, chapters: [], totalAvailable: 0 };

    const chapters = await weakChapterAvailability(db, decoded.uid, exam, focus);
    return { exam, chapters, totalAvailable: chapters.reduce((n, c) => n + c.available, 0) };
  });

// The mixed practice session itself: PYQs from the weak chapters, interleaved,
// unseen questions first. Same no-answers-in-the-list rule as everywhere else.
export const listWeakPyqQuestions = createServerFn({ method: "GET" })
  .validator((data: { token: string; attemptId: string; difficulty?: Difficulty }) => data)
  .handler(async ({ data }): Promise<PyqList> => {
    const decoded = await requireSignedIn(data.token);
    const db = await getDb();
    await ensureQuestionIndexes(db);
    const attempt = await loadOwnedAttempt(db, decoded.uid, data.attemptId);
    const { focus } = await loadAttemptTopicAnalysis(db, attempt);
    const exam = await examForAttempt(db, decoded.uid, attempt);
    if (focus.length === 0) return { questions: [], years: [], total: 0, weak: { chapters: [] } };

    const match: Record<string, unknown> = { ...(await pyqMatch(db, exam)), $or: chapterOr(focus) };
    if (data.difficulty) match.difficulty = data.difficulty;

    const docs = await db.collection("questions").find(match, { projection: QUESTION_PROJECTION }).sort({ _id: 1 }).limit(1000).toArray();
    let questions = await buildQuestions(db, decoded.uid, docs);

    // "year" and "status" are applied client-side (see listPyqQuestions above);
    // pickWeakQuestions below already ranks unsolved questions first regardless.
    const years = [...new Set(questions.map((q) => q.source.year).filter((y): y is string => !!y))].sort((a, b) => b.localeCompare(a));

    // Newest paper first before picking, so "first 12 per chapter" means the most recent ones.
    questions = questions
      .map((q, i) => ({ q, i }))
      .sort((a, b) => (b.q.source.year ?? "").localeCompare(a.q.source.year ?? "") || a.i - b.i)
      .map((x) => x.q);

    const picked = pickWeakQuestions(focus, questions);
    return {
      questions: picked,
      years,
      total: questions.length,
      weak: {
        chapters: focus.map((f) => ({
          subject: f.subject,
          chapter: f.chapter,
          count: picked.filter((q) => weakKey(q.subject, q.chapter) === weakKey(f.subject, f.chapter)).length,
        })),
      },
    };
  });