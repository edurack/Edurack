// Student-side: browse open mentor slots. Booking itself (both free and
// paid) now goes through server-functions/payments.ts — claimFreeItem for
// free offerings, createRazorpayOrder + verifyRazorpayPayment (itemType:
// "mentorSession") for paid ones — so this file no longer duplicates any
// payment logic. See payments.ts's createSessionBookingRecord.
import { createServerFn } from "@tanstack/react-start";
import { adminAuth } from "@/lib/firebase-admin";
import { supabase } from "@/lib/supabase";
import { expandOfferingToSlots } from "@/lib/session-slots";
import type { MentorSessionOffering, OpenSlot, PublicMentorOffering } from "@/lib/session-types";

async function verifyFirebaseToken(token: string) {
  return adminAuth.verifyIdToken(token);
}

function rowToOffering(row: any): MentorSessionOffering {
  return {
    id: row.id,
    mentorId: row.mentor_id,
    title: row.title,
    description: row.description ?? "",
    durationMinutes: row.duration_minutes,
    isFree: row.is_free,
    price: Number(row.price),
    thumbnailUrl: row.thumbnail_url,
    recurringDays: row.recurring_days,
    startTimes: row.start_times,
    dateRangeStart: row.date_range_start,
    dateRangeEnd: row.date_range_end,
    isOngoing: row.is_ongoing,
    active: row.active,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

// TODO: wire to your real Mongo `mentors` collection, same as catalog.ts's
// listPublicMentors — keep this in sync with the identical stub in
// payments.ts (lookupMentorPublicInfo there is used for the notification
// email; this one is used to label offering cards). Until both are wired
// up, offering cards show "Mentor" with no photo.
async function lookupMentorPublicInfo(mentorIds: string[]): Promise<Record<string, { name: string; photoUrl: string | null }>> {
  return {};
}

// Lists every mentor's active offerings plus, for each, its next open
// slots (21-day window).
export const listOpenMentorSessions = createServerFn({ method: "GET" })
  .validator((d: { token: string }) => d)
  .handler(async ({ data }) => {
    await verifyFirebaseToken(data.token);

    const { data: offeringRows, error } = await supabase
      .from("mentor_session_offerings")
      .select("*")
      .eq("active", true);
    if (error) throw new Error(error.message);

    const offerings = (offeringRows ?? []).map(rowToOffering);
    if (offerings.length === 0) return { offerings: [] as PublicMentorOffering[], slotsByOffering: {} as Record<string, OpenSlot[]> };

    const offeringIds = offerings.map((o) => o.id);
    const { data: bookingRows, error: bErr } = await supabase
      .from("mentor_session_bookings")
      .select("offering_id, session_date, start_time")
      .in("offering_id", offeringIds)
      .neq("status", "cancelled");
    if (bErr) throw new Error(bErr.message);

    const bookedKeys = new Set((bookingRows ?? []).map((b: any) => `${b.offering_id}:${b.session_date}:${b.start_time}`));

    const mentorIds = Array.from(new Set(offerings.map((o) => o.mentorId)));
    const mentorInfo = await lookupMentorPublicInfo(mentorIds);

    const publicOfferings: PublicMentorOffering[] = offerings.map((o) => ({
      ...o,
      mentorName: mentorInfo[o.mentorId]?.name ?? "Mentor",
      mentorPhotoUrl: mentorInfo[o.mentorId]?.photoUrl ?? null,
    }));

    const slotsByOffering: Record<string, OpenSlot[]> = {};
    for (const o of offerings) {
      slotsByOffering[o.id] = expandOfferingToSlots(o, bookedKeys);
    }

    return { offerings: publicOfferings, slotsByOffering };
  });

export const listMyBookedSessions = createServerFn({ method: "GET" })
  .validator((d: { token: string }) => d)
  .handler(async ({ data }) => {
    const student = await verifyFirebaseToken(data.token);
    const { data: rows, error } = await supabase
      .from("mentor_session_bookings")
      .select("*, mentor_session_offerings(title)")
      .eq("student_uid", student.uid)
      .order("session_date", { ascending: true })
      .order("start_time", { ascending: true });
    if (error) throw new Error(error.message);
    return { bookings: rows ?? [] };
  });