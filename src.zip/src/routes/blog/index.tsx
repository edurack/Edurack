// src/routes/blog/index.tsx
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState, type ReactNode } from "react";
import { pageHead } from "@/lib/seo";
import { listPublishedPosts } from "@/server-functions/blog-public";
import { BLOG_CATEGORIES, BLOG_CATEGORY_LABELS, resolveBlogPromoAudience } from "@/lib/blog-types";
import type { BlogCategory, PublicBlogPostSummary } from "@/lib/blog-types";
import { EXAM_KEYS, EXAM_LABELS } from "@/lib/admin-types";
import { FreeTestPopup } from "@/components/blog/free-test-popup";
import { BlogCallbackSection } from "@/components/blog/blog-callback-section";
import type { ExamKey } from "@/lib/admin-types";

type BlogSearch = { category?: BlogCategory; examKey?: ExamKey; page?: number };

export const Route = createFileRoute("/blog/")({
  validateSearch: (search: Record<string, unknown>): BlogSearch => ({
    category: BLOG_CATEGORIES.includes(search.category as BlogCategory) ? (search.category as BlogCategory) : undefined,
    examKey: EXAM_KEYS.includes(search.examKey as ExamKey) ? (search.examKey as ExamKey) : undefined,
    page: typeof search.page === "number" ? search.page : Number(search.page) || undefined,
  }),
  loader: async ({ location }) => {
    const search = location.search as BlogSearch;
    return listPublishedPosts({ data: { category: search.category, examKey: search.examKey, page: search.page ?? 1 } });
  },
  // Canonical is always plain /blog: the ?category / ?examKey / ?page
  // variants are filtered views of the same list, not separate pages.
  head: () =>
    pageHead({
      title: "Exam Prep Blog: NEET, JEE, CUET & IPMAT",
      description:
        "Study strategy, exam analysis, mentor stories and platform updates for NEET, JEE, CUET and IPMAT aspirants, from the Edurack team.",
      path: "/blog",
    }),
  component: BlogIndexPage,
});

function BlogIndexPage() {
  const initial = Route.useLoaderData();
  const search = Route.useSearch();
  const navigate = useNavigate({ from: Route.fullPath });

  const [data, setData] = useState(initial);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    setLoading(true);
    listPublishedPosts({ data: { category: search.category, examKey: search.examKey, page: search.page ?? 1 } })
      .then(setData)
      .finally(() => setLoading(false));
  }, [search.category, search.examKey, search.page]);

  function setFilter(patch: Partial<BlogSearch>) {
    navigate({ search: (prev) => ({ ...prev, ...patch, page: undefined }) });
  }

  return (
    <div className="mx-auto max-w-5xl px-4 py-14">
      {/* Filtering by JEE/NEET switches to that exam's link; otherwise general. */}
      <FreeTestPopup audience={resolveBlogPromoAudience({ examKey: search.examKey, category: search.category })} />
      <div className="mb-8">
        <h1 className="font-display text-3xl font-bold tracking-tight text-foreground">Edurack Blog</h1>
        <p className="mt-1 text-sm text-foreground/60">Exam strategy, mentor stories, and what's new on the platform.</p>
      </div>

      <div className="mb-8 flex flex-wrap items-center gap-4">
        <div role="group" aria-label="Filter by category" className="flex flex-wrap items-center gap-2">
          <FilterChip active={!search.category} onClick={() => setFilter({ category: undefined })}>
            All
          </FilterChip>
          {BLOG_CATEGORIES.map((c) => (
            <FilterChip key={c} active={search.category === c} onClick={() => setFilter({ category: c })}>
              {BLOG_CATEGORY_LABELS[c]}
            </FilterChip>
          ))}
        </div>
        <span className="hidden h-4 w-px bg-foreground/10 sm:block" aria-hidden="true" />
        <div role="group" aria-label="Filter by exam" className="flex flex-wrap items-center gap-2">
          <FilterChip active={!search.examKey} onClick={() => setFilter({ examKey: undefined })}>
            Any exam
          </FilterChip>
          {EXAM_KEYS.map((k) => (
            <FilterChip key={k} active={search.examKey === k} onClick={() => setFilter({ examKey: k })}>
              {EXAM_LABELS[k]}
            </FilterChip>
          ))}
        </div>
      </div>

      {data.pinned && (
        <Link to="/blog/$slug" params={{ slug: data.pinned.slug }} className="clay mb-8 flex flex-col overflow-hidden sm:flex-row">
          {data.pinned.coverImageUrl && (
            <img src={data.pinned.coverImageUrl} alt={data.pinned.coverImageAlt} className="h-48 w-full object-cover sm:h-auto sm:w-64" />
          )}
          <div className="p-6">
            <span className="clay-chip inline-block rounded-full px-3 py-1 text-[11px] font-semibold text-foreground/60">Featured</span>
            <p className="mt-2 text-lg font-bold text-foreground">{data.pinned.title}</p>
            <p className="mt-1 text-sm text-foreground/60">{data.pinned.excerpt}</p>
          </div>
        </Link>
      )}

      {loading ? (
        <div className="py-16 text-center text-sm text-foreground/40" role="status" aria-live="polite">
          Loading…
        </div>
      ) : data.posts.length === 0 ? (
        <div className="clay p-10 text-center text-sm text-foreground/60" role="status" aria-live="polite">
          No posts here yet.
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {data.posts.map((p) => (
            <PostCard key={p.id} post={p} />
          ))}
        </div>
      )}

      {data.totalPages > 1 && (
        <nav aria-label="Pagination" className="mt-10 flex items-center justify-center gap-3">
          <button
            disabled={(search.page ?? 1) <= 1}
            onClick={() => navigate({ search: (prev) => ({ ...prev, page: (prev.page ?? 1) - 1 }) })}
            className="clay-chip rounded-full px-4 py-2 text-xs font-semibold disabled:opacity-40"
          >
            Previous
          </button>
          <span className="text-xs text-foreground/50" aria-live="polite">
            Page {data.page} of {data.totalPages}
          </span>
          <button
            disabled={(search.page ?? 1) >= data.totalPages}
            onClick={() => navigate({ search: (prev) => ({ ...prev, page: (prev.page ?? 1) + 1 }) })}
            className="clay-chip rounded-full px-4 py-2 text-xs font-semibold disabled:opacity-40"
          >
            Next
          </button>
        </nav>
      )}

      <BlogCallbackSection examKey={search.examKey} category={search.category} className="mt-16" />
    </div>
  );
}

function FilterChip({ active, onClick, children }: { active: boolean; onClick: () => void; children: ReactNode }) {
  return (
    <button
      onClick={onClick}
      aria-pressed={active}
      className={`rounded-full px-3 py-1.5 text-xs font-semibold transition-colors ${
        active ? "bg-foreground text-background" : "clay-chip text-foreground/60"
      }`}
    >
      {children}
    </button>
  );
}

function PostCard({ post }: { post: PublicBlogPostSummary }) {
  return (
    <Link
      to="/blog/$slug"
      params={{ slug: post.slug }}
      className="clay group flex flex-col overflow-hidden transition hover:-translate-y-0.5 hover:border-primary/40"
    >
      {post.coverImageUrl && (
        <div className="overflow-hidden">
          <img src={post.coverImageUrl} alt={post.coverImageAlt} className="aspect-video w-full object-cover transition duration-500 group-hover:scale-105" />
        </div>
      )}
      <div className="flex flex-1 flex-col p-4">
        <span className="w-fit rounded-full bg-primary/10 px-2.5 py-0.5 text-[11px] font-semibold text-primary">{BLOG_CATEGORY_LABELS[post.category]}</span>
        <p className="mt-2 line-clamp-2 text-sm font-bold leading-snug text-foreground">{post.title}</p>
        <p className="mt-1.5 line-clamp-2 flex-1 text-xs text-foreground/60">{post.excerpt}</p>
        <p className="mt-3 text-[11px] text-foreground/40">{post.readingTimeMinutes} min read</p>
      </div>
    </Link>
  );
}
