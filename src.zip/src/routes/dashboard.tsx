import { MentorshipCompactCard, type UpNextInfo } from "@/components/today-card";
import { PracticePerformanceCard } from "@/components/dashboard/practice-performance-card";
import { PrepSetupCard } from "@/components/dashboard/prep-setup-card";
import { usePracticeStats } from "@/components/dashboard/use-practice-stats";
import { QuickMockCard } from "@/components/quick-mock/quick-mock-card";
import { useQuickMockStatus } from "@/components/quick-mock/use-quick-mock-status";
import { quickMockName, quickMockSearch, type QuickMockStatus } from "@/lib/quick-mock";
import { trackQuickMockClick } from "@/lib/quick-mock-analytics";
import type { PracticeStats } from "@/lib/practice-stats";
import { StudentOfTheWeekBanner } from "@/components/leaderboard-view";
import { PyqHero } from "@/components/dashboard/pyq-hero";
import { ProActiveCard } from "@/components/dashboard/pro-active-card";
import type { DrillAccess } from "@/lib/pro";
import { StreakPopup } from "@/components/dashboard/streak-popup";
import { CompleteProfilePopup } from "@/components/dashboard/complete-profile-popup";
import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { noindexHead } from "@/lib/seo";
import { useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { motion } from "motion/react";
import { IconTrophy as Trophy, IconLoader2 as Loader2, IconSearch as Search, IconBook2 as BookOpen, IconUsersGroup as Users2, IconArrowRight as ArrowRight, IconChevronRight as ChevronRight, IconSchool as GraduationCap, IconStar as Star, IconRosetteDiscountCheck as BadgeCheck, IconTag as Tag, IconClipboardList as ClipboardList, IconX as X, IconGift as Gift, IconUsers as UsersGroupIcon, IconClock as Clock, IconHome as Home, IconCompass as Compass, IconCalendarEvent as CalendarDays, IconLifebuoy as LifeBuoy, IconReceipt as Receipt, IconLink as LinkIcon, IconPlayerPlayFilled as Play, IconCircleCheck as CircleCheck, IconTarget as Target, IconCalendarWeek as CalendarWeek, IconRefresh as Refresh } from "@tabler/icons-react";
import { useAuth } from "@/lib/auth-context";
import { getDashboardBootstrap } from "@/server-functions/dashboard";
import { getProfile } from "@/server-functions/profile";
import { listPublicBundles, listPublicMentorshipBatches, listPublicMentors, listPublicSoldTests } from "@/server-functions/catalog";
import { getMyPurchases, getMyBatchPerformance } from "@/server-functions/student-data";
import { listOpenMentorSessions, listMyBookedSessions } from "@/server-functions/student-sessions";
import { StudentOpenSessionsModule, BookingDialog } from "@/components/student-open-sessions-module";
import { AppHeader } from "@/components/app-header";
import type { OpenSlot, PublicMentorOffering } from "@/lib/session-types";
import { formatForOffering } from "@/lib/session-types";
import { slotStart, formatTime12, formatSlot } from "@/lib/session-time";

export const Route = createFileRoute("/dashboard")({
  head: () => noindexHead("My Dashboard"),
  component: DashboardPage,
});

type Track = "Dropper" | "11th" | "12th" | "";
type TrackFilter = "All" | "Dropper" | "11th" | "12th";
type ExamKey = "neet" | "jee" | "cuet" | "ipmat";
type ExamFilter = "All" | ExamKey;

const EXAM_LABELS: Record<ExamKey, string> = {
  neet: "NEET",
  jee: "JEE",
  cuet: "CUET",
  ipmat: "IPMAT",
};

function resolveExamKey(targetExam: string): ExamKey | null {
  const t = targetExam.toLowerCase();
  if (t.includes("neet")) return "neet";
  if (t.includes("jee")) return "jee";
  if (t.includes("cuet")) return "cuet";
  if (t.includes("ipmat")) return "ipmat";
  return null;
}

type StudentProfile = {
  fullName: string;
  mobile: string;
  city: string;
  targetExam: string;
  track: Track;
  targetYear: number | null;
};

type Bundle = {
  id: string;
  title: string;
  track: string;
  exam?: ExamKey;
  features: string[];
  sellingPrice: number;
  crossedPrice: number;
  discountPercent: number;
  expiryDate: string;
  thumbnailUrl: string | null;
};

type MentorshipBatch = {
  id: string;
  name: string;
  track: string;
  exam?: ExamKey;
  highlights: string[];
  sellingPrice: number;
  crossedPrice: number;
  discountPercent: number;
  thumbnailUrl: string | null;
  mentorName: string | null;
};

type MentorDirectoryEntry = {
  id: string;
  name: string;
  profilePictureUrl: string | null;
  yearOfStudy: string;
  aboutText: string;
  avgRating: number | null;
  reviewCount: number;
  batches: { id: string; name: string; track: string }[];
  searchText: string;
};

type SoldTestEntry = {
  id: string;
  name: string;
  mentorName: string;
  totalQuestions: number;
  durationMinutes: number;
  subjects: string[];
  price: number;
  purchased: boolean;
  searchText: string;
};

function soldTestToEntry(t: {
  id: string;
  name: string;
  mentorName: string;
  totalQuestions: number;
  durationMinutes: number;
  subjects: string[];
  price: number;
}, purchasedKeys: Set<string>): SoldTestEntry {
  return {
    ...t,
    purchased: purchasedKeys.has(`mentorTest:${t.id}`),
    searchText: `${t.name} ${t.mentorName} ${t.subjects.join(" ")}`.toLowerCase(),
  };
}

type Listing = {
  id: string;
  kind: "Test Series" | "Mentorship";
  title: string;
  track: string;
  exam: ExamKey;
  thumbnailUrl: string | null;
  sellingPrice: number;
  crossedPrice: number;
  discountPercent: number;
  metaLine: string;
  metaIcon: typeof BookOpen;
  searchText: string;
  purchased: boolean;
};

function bundleToListing(b: Bundle, purchasedKeys: Set<string>): Listing {
  const exam = b.exam ?? "neet";
  return {
    id: b.id,
    kind: "Test Series",
    title: b.title,
    track: b.track,
    exam,
    thumbnailUrl: b.thumbnailUrl,
    sellingPrice: b.sellingPrice,
    crossedPrice: b.crossedPrice,
    discountPercent: b.discountPercent,
    metaLine: b.features[0] ?? `${EXAM_LABELS[exam]} test series`,
    metaIcon: BookOpen,
    searchText: `${b.title} ${b.track} ${EXAM_LABELS[exam]} ${b.features.join(" ")}`.toLowerCase(),
    purchased: purchasedKeys.has(`bundle:${b.id}`),
  };
}

function batchToListing(b: MentorshipBatch, purchasedKeys: Set<string>): Listing {
  const exam = b.exam ?? "neet";
  return {
    id: b.id,
    kind: "Mentorship",
    title: b.name,
    track: b.track,
    exam,
    thumbnailUrl: b.thumbnailUrl,
    sellingPrice: b.sellingPrice,
    crossedPrice: b.crossedPrice,
    discountPercent: b.discountPercent,
    metaLine: b.mentorName ? `Mentor: ${b.mentorName}` : "Mentor: unassigned",
    metaIcon: Users2,
    searchText: `${b.name} ${b.track} ${EXAM_LABELS[exam]} ${b.highlights.join(" ")} ${b.mentorName ?? ""}`.toLowerCase(),
    purchased: purchasedKeys.has(`mentorship:${b.id}`),
  };
}

const TRACK_FILTERS: TrackFilter[] = ["All", "Dropper", "11th", "12th"];
const EXAM_FILTERS: ExamFilter[] = ["All", "neet", "jee", "cuet", "ipmat"];

// "sessions" moved to the #2 slot (right after the personalized "For you"
// tab, or first if the student has no track set yet) — it was previously
// last, after four other tabs, which buried the platform's clearest
// engagement hook (book a real mentor, often for free) behind everything
// else. The free-sessions banner below covers the "always visible, no
// tab-click required" half of that; this covers "when they do explore
// tabs, it's not the last thing they'd ever find."
type MainTab = "forYou" | "sessions" | "series" | "mentorship" | "tests" | "mentors";

type View = "home" | "explore" | "sessions" | "tests" | "mentors";

type BookingRow = {
  id: string;
  session_date: string;
  start_time: string;
  duration_minutes: number;
  is_free: boolean;
  status: "upcoming" | "completed" | "cancelled" | "no_show";
  meeting_link: string | null;
  mentor_session_offerings?: { title: string };
};

type BatchPerf = { bundleId: string; bundleTitle: string; exam?: string; testsAttempted: number; totalAttempts: number; averagePercent: number; bestPercent: number; percentSum?: number };

// Slots are India wall-clock; parse them as such, not in the browser's timezone.
const slotDate = (r: BookingRow) => slotStart(r.session_date, r.start_time);

function untilLabel(d: Date) {
  const h = Math.round((d.getTime() - Date.now()) / 36e5);
  if (h < 1) return "Starting soon";
  if (h < 24) return `In ${h} hour${h === 1 ? "" : "s"}`;
  const days = Math.round(h / 24);
  return days === 1 ? "Tomorrow" : `In ${days} days`;
}

function DashboardPage() {
  const { user, loading } = useAuth();
  const navigate = useNavigate();
  const [profile, setProfile] = useState<StudentProfile | null>(null);
  const [bundles, setBundles] = useState<Bundle[] | null>(null);
  const [batches, setBatches] = useState<MentorshipBatch[] | null>(null);
  const [mentors, setMentors] = useState<MentorDirectoryEntry[] | null>(null);
  const [soldTests, setSoldTests] = useState<SoldTestEntry[] | null>(null);
  const [purchasedKeys, setPurchasedKeys] = useState<Set<string> | null>(null);
  const [sessionOfferings, setSessionOfferings] = useState<PublicMentorOffering[] | null>(null);
  const [sessionSlots, setSessionSlots] = useState<Record<string, OpenSlot[]>>({});
  const [trackFilter, setTrackFilter] = useState<TrackFilter>("All");
  const [examFilter, setExamFilter] = useState<ExamFilter>("All");
  const [query, setQuery] = useState("");
  const [tab, setTab] = useState<MainTab>("series");
  const didDefaultToForYou = useRef(false);
  const [view, setView] = useState<View>("home");
  const [bookings, setBookings] = useState<BookingRow[] | null>(null);
  const [perf, setPerf] = useState<BatchPerf[] | null>(null);
  // The practice numbers, fetched once and shared by the hero and the performance card so they always agree.
  const { stats: practiceStats, failed: statsFailed, reload: reloadStats } = usePracticeStats();
  // Today's Quick Mock allowance (free one ready / used up / Pro-only / unfinished), for the card and the sidebar entry.
  const { access: proAccess, status: qmStatus, loaded: qmLoaded } = useQuickMockStatus();

  // One request for the whole dashboard (profile, catalog, purchases, sessions,
  // bookings, performance) — see server-functions/dashboard.ts. If that request
  // fails, or a section comes back empty, only the missing sections are fetched
  // with the individual server functions, so a problem in the combined request
  // can never leave a page spinning forever. Errors are logged to the console.
  useEffect(() => {
    if (!user) return;
    let cancelled = false;
    (async () => {
      try {
        const token = await user.getIdToken();

        let res: any = null;
        try {
          res = await getDashboardBootstrap({ data: { token } });
        } catch (err) {
          console.error("[dashboard] combined request failed, falling back to per-section requests:", err);
        }
        if (cancelled) return;

        const section = async (name: string, have: any, run: () => Promise<any>): Promise<any> => {
          if (have) return have;
          try {
            return await run();
          } catch (err) {
            console.error(`[dashboard] ${name} failed:`, err);
            return null;
          }
        };
        const [profileRes, bundlesRes, batchesRes, mentorsRes, soldTestsRes, purchasesRes, sessionsRes, bookingsRes, performanceRes] = await Promise.all([
          section("profile", res?.profile, () => getProfile({ data: { token } })),
          section("bundles", res?.bundles, () => listPublicBundles({ data: { token } })),
          section("batches", res?.batches, () => listPublicMentorshipBatches({ data: { token } })),
          section("mentors", res?.mentors, () => listPublicMentors({ data: { token } })),
          section("soldTests", res?.soldTests, () => listPublicSoldTests({ data: { token } })),
          section("purchases", res?.purchases, () => getMyPurchases({ data: { token } })),
          section("sessions", res?.sessions, () => listOpenMentorSessions({ data: { token } })),
          section("bookings", res?.bookings, () => listMyBookedSessions({ data: { token } })),
          section("performance", res?.performance, () => getMyBatchPerformance({ data: { token } })),
        ]);
        if (cancelled) return;

        const p = profileRes?.profile;
        if (p) {
          setProfile({
            fullName: p.fullName,
            mobile: p.mobile ?? "",
            city: p.city ?? "",
            targetExam: p.targetExam || "",
            track: (p.track as Track) || "",
            targetYear: typeof p.targetYear === "number" ? p.targetYear : null,
          });
        }
        if (bundlesRes) setBundles(bundlesRes.bundles as Bundle[]);
        if (batchesRes) setBatches(batchesRes.batches as MentorshipBatch[]);
        if (mentorsRes) setMentors(mentorsRes.mentors as MentorDirectoryEntry[]);
        if (purchasesRes) {
          const purchasedSet = new Set<string>(purchasesRes.purchases.map((pu: { itemType: string; itemId: string }) => `${pu.itemType}:${pu.itemId}`));
          setPurchasedKeys(purchasedSet);
          if (soldTestsRes) {
            setSoldTests((soldTestsRes.tests as Omit<SoldTestEntry, "purchased" | "searchText">[]).map((t) => soldTestToEntry(t, purchasedSet)));
          }
        }
        if (sessionsRes) {
          setSessionOfferings(sessionsRes.offerings as PublicMentorOffering[]);
          setSessionSlots(sessionsRes.slotsByOffering as Record<string, OpenSlot[]>);
        }
        setBookings((bookingsRes?.bookings as BookingRow[] | undefined) ?? []);
        setPerf((performanceRes?.batches as BatchPerf[] | undefined) ?? []);
      } catch (err) {
        console.error("[dashboard] load failed:", err);
        if (cancelled) return;
        setBookings([]);
        setPerf([]);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [user]);

  useEffect(() => {
    if (!loading && !user) {
      navigate({ to: "/auth" });
    }
  }, [loading, user, navigate]);

  async function loadSessions() {
    if (!user) return;
    const token = await user.getIdToken();
    const { offerings, slotsByOffering } = await listOpenMentorSessions({ data: { token } });
    setSessionOfferings(offerings as PublicMentorOffering[]);
    setSessionSlots(slotsByOffering as Record<string, OpenSlot[]>);
  }

  const allListings = useMemo(() => {
    if (!bundles || !batches || !purchasedKeys) return null;
    return [
      ...bundles.map((b) => bundleToListing(b, purchasedKeys)),
      ...batches.map((b) => batchToListing(b, purchasedKeys)),
    ];
  }, [bundles, batches, purchasedKeys]);

  const track = profile?.track ?? "";
  const examKey = profile?.targetExam ? resolveExamKey(profile.targetExam) : null;
  const firstName = profile?.fullName?.split(" ")[0] || user?.displayName?.split(" ")[0] || "";
  const ownedCount = purchasedKeys?.size ?? 0;

  useEffect(() => {
    if (track && !didDefaultToForYou.current) {
      setTab("forYou");
      didDefaultToForYou.current = true;
    }
  }, [track]);

  // A listing's track can be "11th", "12th", "Dropper", or "All" (an admin
  // choice meaning open to every track) — "All" must match everyone, not
  // just students who literally have "All" as their own track.
  const matchesTrack = (listingTrack: string, wanted: string) => wanted === "All" || listingTrack === wanted || listingTrack === "All";

  const recommended = useMemo(() => {
    if (!allListings || !track) return [];
    return allListings.filter((l) => matchesTrack(l.track, track) && (!examKey || l.exam === examKey));
  }, [allListings, track, examKey]);

  const seriesListings = useMemo(() => {
    if (!allListings) return [];
    return allListings.filter(
      (l) => l.kind === "Test Series" && matchesTrack(l.track, trackFilter) && (examFilter === "All" || l.exam === examFilter),
    );
  }, [allListings, trackFilter, examFilter]);

  const mentorshipListings = useMemo(() => {
    if (!allListings) return [];
    return allListings.filter(
      (l) => l.kind === "Mentorship" && matchesTrack(l.track, trackFilter) && (examFilter === "All" || l.exam === examFilter),
    );
  }, [allListings, trackFilter, examFilter]);

  // The Tests view's "For you" shelf: test-series bundles (not mentorships)
  // that fit the student's track/exam, same "All" rule as above. Falls back
  // to exam-only matching when the student hasn't set a track yet.
  const testSeriesForYou = useMemo(() => {
    if (!allListings) return [];
    return allListings.filter(
      (l) => l.kind === "Test Series" && (!track || matchesTrack(l.track, track)) && (!examKey || l.exam === examKey),
    );
  }, [allListings, track, examKey]);

  // Nearest 1-2 open slots per free offering, flattened and sorted by
  // soonest first — what the always-visible banner actually shows. Capped
  // at 6 cards so the strip stays scannable rather than becoming its own
  // wall of content.
  const featuredFreeSlots = useMemo(() => {
    if (!sessionOfferings) return [];
    const out: { offering: PublicMentorOffering; slot: OpenSlot }[] = [];
    for (const o of sessionOfferings) {
      if (!o.isFree) continue;
      const slots = sessionSlots[o.id] ?? [];
      if (slots.length === 0) continue;
      out.push({ offering: o, slot: slots[0] });
    }
    return out.sort((a, b) => (a.slot.date + a.slot.startTime).localeCompare(b.slot.date + b.slot.startTime)).slice(0, 6);
  }, [sessionOfferings, sessionSlots]);

  const q = query.trim().toLowerCase();
  const hasQuery = q.length > 0;

  const matchedMentors = useMemo(() => {
    if (!mentors || !q) return [];
    return mentors.filter((m) => m.searchText.includes(q)).slice(0, 5);
  }, [mentors, q]);

  const matchedListings = useMemo(() => {
    if (!allListings || !q) return [];
    return allListings.filter((l) => l.searchText.includes(q)).slice(0, 8);
  }, [allListings, q]);

  const matchedTests = useMemo(() => {
    if (!soldTests || !q) return [];
    return soldTests.filter((t) => t.searchText.includes(q)).slice(0, 5);
  }, [soldTests, q]);

  if (loading || !user) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <Loader2 className="h-6 w-6 animate-spin text-foreground/40" />
      </div>
    );
  }

  const freeSessionCount = featuredFreeSlots.length;
  const ownedListings = (allListings ?? []).filter((l) => l.purchased);
  const ownedTests = (soldTests ?? []).filter((t) => t.purchased);
  const now = new Date();
  const upcoming = (bookings ?? []).filter((r) => r.status === "upcoming" && slotDate(r) >= now).sort((a, b) => slotDate(a).getTime() - slotDate(b).getTime());
  const hour = now.getHours();
  const greet = hour < 12 ? "Good morning" : hour < 17 ? "Good afternoon" : "Good evening";

  const nav: { key: View; label: string; icon: typeof Home; badge?: number }[] = [
    { key: "home", label: "Overview", icon: Home },
    { key: "explore", label: "Explore", icon: Compass },
    { key: "sessions", label: "Sessions", icon: CalendarDays, badge: freeSessionCount || undefined },
    { key: "tests", label: "Tests", icon: ClipboardList },
    { key: "mentors", label: "Mentors", icon: Users2 },
  ];
  const title = view === "home" ? (firstName ? `${greet}, ${firstName}` : greet) : nav.find((n) => n.key === view)!.label;
  const showFilters = view === "explore" && (tab === "series" || tab === "mentorship");
  const exploreTabs = [...(track ? [["forYou", "For you"] as const] : []), ["series", "Test series"] as const, ["mentorship", "Mentorships"] as const];

  return (
    <div className="min-h-screen bg-background">
      <AppHeader user={user} displayName={profile?.fullName} />
      <StreakPopup />
      <CompleteProfilePopup
        // Never interrupt a student who hasn't answered a single question yet: practice first, paperwork later.
        hold={!statsFailed && (practiceStats === null || practiceStats.questionsAnswered === 0)}
        profile={profile ? { fullName: profile.fullName, mobile: profile.mobile, city: profile.city } : null}
        onSaved={(next) => setProfile((prev) => (prev ? { ...prev, ...next } : prev))}
      />

      <div className="mx-auto flex max-w-7xl gap-10 px-4 sm:px-6">
        {/* ── Sidebar (desktop) ─────────────────────────────── */}
        <aside className="sticky top-24 hidden h-[calc(100vh-7rem)] w-56 shrink-0 flex-col justify-between py-8 md:flex">
          <nav className="space-y-1">
            <p className="px-3 pb-1 text-xs font-bold uppercase tracking-wider text-foreground/55">Practice</p>
            <Link to="/pyq" className="mb-3 flex min-h-12 items-center gap-3 rounded-2xl bg-gradient-to-r from-primary to-primary/80 px-3 text-sm font-extrabold text-primary-foreground shadow-md transition-transform hover:-translate-y-0.5">
              <ClipboardList className="h-5 w-5" />PYQ Practice
              <span className="ml-auto rounded-full bg-amber-300 px-1.5 py-0.5 text-[10px] font-extrabold uppercase text-amber-950">Free</span>
            </Link>
            {/* Quick Mock sits right under PYQ Practice: same practice family, one tap, same engine. */}
            <Link to="/pyq-drill" search={quickMockSearch({ src: "sidebar", drillId: qmStatus.kind === "resume" ? qmStatus.drillId : undefined })} onClick={() => trackQuickMockClick("sidebar", { state: qmStatus.kind })} data-testid="sidebar-quick-mock" className="mb-3 flex min-h-11 items-center gap-3 rounded-xl border border-border px-3 text-sm font-bold text-foreground transition-colors hover:border-primary hover:text-primary">
              <Clock className="h-5 w-5" />{quickMockName(profile?.targetExam)}
              {qmStatus.kind === "ready" && <span className="ml-auto rounded-full bg-emerald-500/15 px-1.5 py-0.5 text-[10px] font-extrabold uppercase text-emerald-700 dark:text-emerald-300">{qmStatus.unlimited ? "Pro" : "Free"}</span>}
              {qmStatus.kind === "resume" && <span className="ml-auto rounded-full bg-amber-300 px-1.5 py-0.5 text-[10px] font-extrabold uppercase text-amber-950">Resume</span>}
            </Link>
            <p className="px-3 pb-1 pt-3 text-xs font-bold uppercase tracking-wider text-foreground/55">Learn and book</p>
            {nav.map((n) => (
              <button key={n.key} type="button" onClick={() => { setView(n.key); setQuery(""); }} className={`flex min-h-12 w-full items-center gap-3 rounded-xl px-3 text-[15px] font-bold transition-colors ${view === n.key ? "bg-primary/15 text-primary ring-1 ring-primary/25" : "text-foreground/80 hover:bg-secondary hover:text-foreground"}`}>
                <n.icon className="h-5 w-5" />{n.label}
                {n.badge != null && <span className="ml-auto rounded-full bg-primary px-1.5 py-0.5 text-[11px] text-primary-foreground">{n.badge}</span>}
              </button>
            ))}
          </nav>
          <nav className="space-y-1 border-t border-border pt-4">
            <p className="px-3 pb-1 text-xs font-bold uppercase tracking-wider text-foreground/55">Your account</p>
            {([["/my-sessions", "My bookings", CalendarDays], ["/purchases", "Purchases", Receipt], ["/tickets", "Support", LifeBuoy], ["/profile", "Profile", GraduationCap]] as const).map(([to, label, Icon]) => (
              <Link key={to} to={to} className="flex min-h-11 items-center gap-3 rounded-xl px-3 text-sm font-semibold text-foreground/80 transition-colors hover:bg-secondary hover:text-foreground"><Icon className="h-4 w-4" />{label}</Link>
            ))}
          </nav>
        </aside>

        {/* ── Main ──────────────────────────────────────────── */}
        <main className="min-w-0 flex-1 pb-28 pt-6 md:pb-12 md:pt-8">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div className="min-w-0">
              {view === "home" && <p className="mb-1 inline-flex items-center gap-2 rounded-full bg-primary/10 px-3 py-1 text-xs font-bold uppercase tracking-wider text-primary"><CalendarWeek className="h-3.5 w-3.5" />{now.toLocaleDateString("en-IN", { weekday: "long", day: "numeric", month: "long" })}</p>}
              <h1 className="font-display text-3xl font-extrabold leading-tight tracking-tight text-foreground sm:text-4xl">{view === "home" && firstName ? (<>{greet}, <span className="text-primary">{firstName}</span></>) : title}</h1>
            </div>
            <label className="flex min-h-12 w-full items-center gap-3 rounded-full border border-foreground/20 bg-card px-4 shadow-sm transition-colors focus-within:border-primary sm:max-w-xs">
              <Search className="h-4 w-4 shrink-0 text-foreground/70" />
              <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search mentors, courses, tests…" className="w-full bg-transparent text-[15px] placeholder:text-foreground/55 focus:outline-none" />
              {hasQuery && <button type="button" onClick={() => setQuery("")} aria-label="Clear search" className="grid h-8 w-8 shrink-0 place-items-center rounded-full text-foreground/70 hover:bg-secondary"><X className="h-4 w-4" /></button>}
            </label>
          </div>

          <div className="mt-6">
            {hasQuery ? (
              <SearchResults query={query} matchedMentors={matchedMentors} matchedListings={matchedListings} matchedTests={matchedTests} loading={mentors === null || allListings === null || soldTests === null} />
            ) : view === "home" ? (
              <Overview
                upcoming={upcoming} bookingsLoaded={bookings !== null} perf={perf}
                stats={practiceStats} statsFailed={statsFailed} reloadStats={reloadStats} qmStatus={qmStatus} qmLoaded={qmLoaded} proAccess={proAccess}
                profile={profile} onProfileSaved={(next) => setProfile((prev) => (prev ? { ...prev, ...next } as StudentProfile : prev))}
                ownedListings={ownedListings} ownedTests={ownedTests} freeSlots={featuredFreeSlots} mentors={mentors} offerings={sessionOfferings} slotsByOffering={sessionSlots}
                recommended={(track ? recommended : (allListings ?? []).filter((l) => l.kind === "Test Series")).slice(0, 3)}
                go={setView} getToken={() => user.getIdToken()} onBooked={loadSessions}
              />
            ) : view === "explore" ? (
              <>
                <div className="inline-flex rounded-full border border-foreground/20 p-1">
                  {exploreTabs.map(([k, label]) => (
                    <button key={k} type="button" onClick={() => setTab(k)} className={`min-h-10 rounded-full px-4 text-sm font-bold transition-colors ${tab === k ? "bg-foreground text-background" : "text-foreground/80"}`}>{label}</button>
                  ))}
                </div>
                {showFilters && (
                  <div className="mt-4 flex flex-col gap-2">
                    <div className="flex flex-wrap gap-2">{EXAM_FILTERS.map((e) => <FilterChip key={e} active={examFilter === e} onClick={() => setExamFilter(e)}>{e === "All" ? "All exams" : EXAM_LABELS[e]}</FilterChip>)}</div>
                    <div className="flex flex-wrap gap-2">{TRACK_FILTERS.map((t) => <FilterChip key={t} active={trackFilter === t} onClick={() => setTrackFilter(t)}>{t === "All" ? "All tracks" : t}</FilterChip>)}</div>
                  </div>
                )}
                <div className="mt-6">
                  {tab === "forYou" && <ListingGrid listings={recommended} loading={allListings === null} emptyText={`Nothing published for ${track}${examKey ? ` · ${EXAM_LABELS[examKey]}` : ""} yet.`} showKindBadge />}
                  {tab === "series" && <ListingGrid listings={seriesListings} loading={allListings === null} emptyText="No test series match this filter." />}
                  {tab === "mentorship" && <ListingGrid listings={mentorshipListings} loading={allListings === null} emptyText="No mentorships match this filter." />}
                </div>
              </>
            ) : view === "sessions" ? (
              <div>
                <div className="mb-5 flex items-center justify-between gap-3">
                  <p className="text-sm text-foreground/70">Free and paid sessions open for booking right now.</p>
                  <Link to="/my-sessions" className={linkAction}>My booked sessions</Link>
                </div>
                <StudentOpenSessionsModule getToken={() => user.getIdToken()} />
              </div>
            ) : view === "tests" ? (
              <div className="space-y-10">
                <div>
                  <div className="mb-4 flex items-center justify-between gap-3">
                    <h2 className="font-display text-xl font-extrabold tracking-tight">Test series</h2>
                    <button type="button" onClick={() => { setView("explore"); setTab("series"); }} className={linkAction}>Browse all</button>
                  </div>
                  <ListingGrid
                    listings={testSeriesForYou}
                    loading={allListings === null}
                    emptyText={`No test series published for ${track || "your track"}${examKey ? ` · ${EXAM_LABELS[examKey]}` : ""} yet.`}
                    showKindBadge
                  />
                </div>
                <div>
                  <h2 className="mb-4 font-display text-xl font-extrabold tracking-tight">Individual tests</h2>
                  <SoldTestGrid tests={soldTests} />
                </div>
              </div>
            ) : (
              <MentorGrid mentors={mentors} />
            )}
          </div>
        </main>
      </div>

      {/* ── Bottom tab bar (phones) ─────────────────────────── */}
      <nav className="fixed inset-x-0 bottom-0 z-40 grid grid-cols-5 border-t border-border bg-background/95 backdrop-blur-xl md:hidden" style={{ paddingBottom: "env(safe-area-inset-bottom)" }}>
        {nav.map((n) => (
          <button key={n.key} type="button" onClick={() => { setView(n.key); setQuery(""); window.scrollTo({ top: 0 }); }} aria-current={view === n.key} className={`relative flex min-h-16 flex-col items-center justify-center gap-1 text-xs font-bold transition-colors ${view === n.key ? "text-primary" : "text-foreground/65"}`}>
                        <span className={`relative grid h-8 w-14 place-items-center rounded-full transition-colors ${view === n.key ? "bg-primary/15" : ""}`}><n.icon className="h-6 w-6" />{n.badge != null && <span className="absolute -right-2 -top-1.5 grid h-4 min-w-4 place-items-center rounded-full bg-primary px-1 text-[10px] text-primary-foreground">{n.badge}</span>}</span>
            {n.label}
          </button>
        ))}
      </nav>
    </div>
  );
}

// ─── Overview (the actual dashboard) ────────────────────────────────────
function Panel({ title, icon, action, children, className = "" }: { title: string; icon?: ReactNode; action?: ReactNode; children: ReactNode; className?: string }) {
  return (
    <section className={`min-w-0 rounded-3xl border border-foreground/15 bg-card p-5 shadow-sm sm:p-6 ${className}`}>
      <div className="mb-4 flex items-center justify-between gap-3">
        <h2 className="flex items-center gap-2.5 font-display text-lg font-extrabold tracking-tight">{icon && <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-primary/15 text-primary" aria-hidden>{icon}</span>}{title}</h2>
        {action}
      </div>
      {children}
    </section>
  );
}

/** Names each group of cards on the overview, so the page reads as sections instead of one long stack. */
function SectionHeading({ children }: { children: ReactNode }) {
  return (
    <div className="flex items-center gap-3 px-1 pt-5">
      <span className="h-6 w-1.5 rounded-full bg-primary" aria-hidden />
      <h2 className="font-display text-xl font-extrabold tracking-tight text-foreground">{children}</h2>
    </div>
  );
}

/** Four numbers a returning student wants at a glance. Tiles with something to do (revise) are links. */
function Snapshot({ stats }: { stats: PracticeStats }) {
  const o = stats.overall;
  const tiles: { icon: typeof Home; label: string; value: string; tone: string; to?: boolean }[] = [
    { icon: CircleCheck, label: "Questions solved", value: o.solved.toLocaleString("en-IN"), tone: "bg-emerald-500/15 text-emerald-600 dark:text-emerald-300" },
    { icon: Target, label: "Accuracy", value: o.accuracy !== null ? `${o.accuracy}%` : "–", tone: "bg-sky-500/15 text-sky-600 dark:text-sky-300" },
    { icon: CalendarWeek, label: "This week", value: o.weekAnswered.toLocaleString("en-IN"), tone: "bg-violet-500/15 text-violet-600 dark:text-violet-300" },
    { icon: Refresh, label: o.due > 0 ? "Mistakes to revise" : "Nothing to revise", value: o.due.toLocaleString("en-IN"), tone: "bg-amber-500/15 text-amber-700 dark:text-amber-300", to: o.due > 0 },
  ];
  const base = "flex min-w-0 items-center gap-3 rounded-2xl border border-foreground/15 bg-card p-3.5 shadow-sm";
  return (
    <div className="grid grid-cols-2 gap-3 lg:grid-cols-4" aria-label="Your practice at a glance">
      {tiles.map((t) => {
        const inner = (
          <>
            <span className={`grid h-11 w-11 shrink-0 place-items-center rounded-xl ${t.tone}`} aria-hidden><t.icon className="h-5 w-5" /></span>
            <span className="min-w-0">
              <span className="block text-2xl font-extrabold leading-none tabular-nums text-foreground">{t.value}</span>
              <span className="mt-1 block truncate text-[13px] font-semibold text-foreground/70">{t.label}</span>
            </span>
          </>
        );
        return t.to ? (
          <Link key={t.label} to="/pyq" search={{ practice: true, session: "due" }} className={`${base} transition-colors hover:border-primary`}>{inner}</Link>
        ) : (
          <div key={t.label} className={base}>{inner}</div>
        );
      })}
    </div>
  );
}

const linkAction = "inline-flex min-h-10 items-center text-sm font-bold text-primary underline-offset-4 hover:underline";

function Overview({ upcoming, bookingsLoaded, perf, stats, statsFailed, reloadStats, qmStatus, qmLoaded, proAccess, profile, onProfileSaved, ownedListings, ownedTests, freeSlots, mentors, offerings, slotsByOffering, recommended, go, getToken, onBooked }: {
  upcoming: BookingRow[]; bookingsLoaded: boolean; perf: BatchPerf[] | null;
  stats: PracticeStats | null; statsFailed: boolean; reloadStats: () => void; qmStatus: QuickMockStatus; qmLoaded: boolean; proAccess: DrillAccess | null;
  profile: StudentProfile | null; onProfileSaved: (next: Partial<StudentProfile>) => void;
  ownedListings: Listing[]; ownedTests: SoldTestEntry[]; freeSlots: { offering: PublicMentorOffering; slot: OpenSlot }[]; mentors: MentorDirectoryEntry[] | null; offerings: PublicMentorOffering[] | null; slotsByOffering: Record<string, OpenSlot[]>; recommended: Listing[];
  go: (v: View) => void; getToken: () => Promise<string>; onBooked: () => void;
}) {
  const navigate = useNavigate();
  const next = upcoming[0];
  const continueCount = ownedListings.length + ownedTests.length;
  // A student who has never answered a question gets a short page: one clear action, then the rest further down.
  // (Until the numbers load we assume "returning" so nothing is hidden and then pops back in.)
  const isNew = stats !== null && stats.questionsAnswered === 0;
  // PYQ practice isn't a tile any more: it is the hero above and the first item in the sidebar / bottom bar.
  const actions: { icon: typeof Home; label: string; sub: string; to?: string; onClick?: () => void; highlight?: boolean }[] = [
    { icon: Trophy, label: "Leaderboard", sub: "Top PYQ solvers this week", to: "/leaderboard" },
    { icon: Play, label: "CBT demo", sub: "Exam-format demo", to: "/simulator/live" },
    { icon: Users2, label: "Mentors", sub: "Who cleared your exam", onClick: () => go("mentors") },
    { icon: Compass, label: "Courses", sub: "Series and mentorships", onClick: () => go("explore") },
    { icon: LifeBuoy, label: "Support", sub: "Raise a ticket", to: "/tickets" },
  ];
  // What the mentorship card shows.
  const upNext: UpNextInfo = next
    ? {
        state: "session",
        date: slotDate(next).toLocaleDateString("en-IN", { weekday: "short", day: "numeric", month: "short", timeZone: "Asia/Kolkata" }),
        meta: `${formatTime12(next.start_time)} IST · ${next.duration_minutes} min · ${untilLabel(slotDate(next))}`,
        title: next.mentor_session_offerings?.title ?? "Mentor session",
        joinUrl: next.meeting_link ?? undefined,
        total: upcoming.length,
      }
    : !bookingsLoaded
      ? { state: "loading" }
      : {
          state: "empty",
          text: freeSlots.length > 0 ? `${freeSlots.length} free mentor session${freeSlots.length === 1 ? " is" : "s are"} open right now.` : "Book a session with a mentor who has cleared your exam.",
        };

  const chip = "group flex min-w-0 flex-col items-center gap-2 rounded-2xl px-1 py-2 text-center transition-colors hover:bg-secondary";
  const chipIcon = "grid h-14 w-14 place-items-center rounded-2xl bg-primary/15 text-primary transition-transform group-hover:-translate-y-0.5";

  return (
    <div className="space-y-5">
      {/* A student with an active Edurack Pro plan sees it first. Renders nothing otherwise. */}
      <ProActiveCard access={proAccess} />

      {/* 1. PYQ practice leads the page: "Start your first 5" for a new student, "Continue practising" + today's question + streak otherwise. */}
      <PyqHero stats={stats} statsFailed={statsFailed} />
      {!isNew && stats && <Snapshot stats={stats} />}
      <QuickMockCard status={qmStatus} loaded={qmLoaded} exam={profile?.targetExam} source="dashboard" />
      {/* Exam, class and target year: only what's missing, one tap each, never blocks practice. */}
      <PrepSetupCard
        profile={profile ? { targetExam: profile.targetExam, track: profile.track, targetYear: profile.targetYear } : null}
        deferYear={isNew}
        onSaved={(n) => onProfileSaved({ ...(n.targetExam !== undefined ? { targetExam: n.targetExam ?? "" } : {}), ...(n.track !== undefined ? { track: (n.track ?? "") as Track } : {}), ...(n.targetYear !== undefined ? { targetYear: n.targetYear ?? null } : {}) })}
      />

      {/* 2. Mentors to talk to, each with a one-time guidance session that can be booked right here. */}
      <MentorsForYou mentors={mentors} offerings={offerings} slotsByOffering={slotsByOffering} track={profile?.track ?? ""} onSeeAll={() => go("mentors")} getToken={getToken} onBooked={onBooked} />

      {/* 3. How it is going. */}
      <SectionHeading>Your progress</SectionHeading>
      <PracticePerformanceCard stats={stats} failed={statsFailed} onRetry={reloadStats} targetExam={profile?.targetExam} tests={perf} />
      {!isNew && <StudentOfTheWeekBanner />}

      {/* 4. Everything else, one tap away. */}
      {!isNew && (
        <nav aria-label="Shortcuts" className="grid grid-cols-5 gap-1 rounded-3xl border border-foreground/15 bg-card p-2 shadow-sm">
          {actions.map((a) => {
            const inner = (<><span className={chipIcon}><a.icon className="h-6 w-6" /></span><span className="text-[13px] font-bold leading-tight text-foreground">{a.label}</span></>);
            return a.to ? <Link key={a.label} to={a.to as "/leaderboard"} aria-label={`${a.label}: ${a.sub}`} className={chip}>{inner}</Link> : <button key={a.label} type="button" onClick={a.onClick} aria-label={`${a.label}: ${a.sub}`} className={chip}>{inner}</button>;
          })}
        </nav>
      )}

      <MentorshipCompactCard info={upNext} onBrowse={() => go("sessions")} />
      <div className={`grid grid-cols-1 gap-4 ${isNew ? "" : "lg:grid-cols-2"}`}>
        <Panel title="Free sessions open" icon={<Gift className="h-5 w-5" />} action={freeSlots.length > 0 ? <button type="button" onClick={() => go("sessions")} className={linkAction}>See all</button> : undefined}>
          {freeSlots.length === 0 ? <p className="text-sm text-foreground/70">No free sessions are open right now. Check back soon.</p> : <FreeSlotList slots={freeSlots} getToken={getToken} onBooked={onBooked} />}
        </Panel>
        {!isNew && (
          <Panel title="Continue learning" icon={<BookOpen className="h-5 w-5" />} action={continueCount > 0 ? <Link to="/purchases" className={linkAction}>All purchases</Link> : undefined}>
            {continueCount === 0 ? (
              <div className="text-sm text-foreground/70">You haven't enrolled in anything yet. <button type="button" onClick={() => go("explore")} className="font-bold text-primary hover:underline">Explore courses</button></div>
            ) : (
              <div className="-mx-2">
                {ownedListings.slice(0, 3).map((l) => (
                  <ResultRow key={`${l.kind}-${l.id}`} onClick={() => navigate({ to: "/course/$kind/$id", params: { kind: l.kind === "Test Series" ? "bundle" : "mentorship", id: l.id } })}
                    icon={l.thumbnailUrl ? <img src={l.thumbnailUrl} alt="" className="h-full w-full object-cover" /> : l.kind === "Test Series" ? <BookOpen className="h-4 w-4" /> : <Users2 className="h-4 w-4" />}
                    title={l.title} sub={`${EXAM_LABELS[l.exam]} · ${l.kind}`} />
                ))}
                {ownedTests.slice(0, 2).map((t) => (
                  <ResultRow key={t.id} onClick={() => navigate({ to: "/sold-test/$id", params: { id: t.id } })} icon={<Tag className="h-4 w-4" />} title={t.name} sub={`By ${t.mentorName} · ${t.totalQuestions}Q`} />
                ))}
              </div>
            )}
          </Panel>
        )}
      </div>

      {recommended.length > 0 && (
        <section className="pt-2">
          <div className="mb-4 flex items-center justify-between"><h2 className="font-display text-xl font-extrabold tracking-tight">Recommended for you</h2><button type="button" onClick={() => go("explore")} className={linkAction}>Explore all</button></div>
          <div className={GRID}>{recommended.map((l, i) => <ListingCard key={`${l.kind}-${l.id}`} listing={l} index={i} />)}</div>
        </section>
      )}
    </div>
  );
}

/**
 * "Mentors for you": a swipeable row of mentor profiles. Each card carries the mentor's next one-time session (1:1 preferred)
 * with its length, price and time, bookable in place. Mentors with an open session and a matching track come first.
 */
function MentorsForYou({ mentors, offerings, slotsByOffering, track, onSeeAll, getToken, onBooked }: {
  mentors: MentorDirectoryEntry[] | null; offerings: PublicMentorOffering[] | null; slotsByOffering: Record<string, OpenSlot[]>;
  track: string; onSeeAll: () => void; getToken: () => Promise<string>; onBooked: () => void;
}) {
  const [booking, setBooking] = useState<{ offering: PublicMentorOffering; slot: OpenSlot } | null>(null);
  const picks = useMemo(() => {
    if (!mentors) return [];
    type Offer = { offering: PublicMentorOffering; slot: OpenSlot };
    const when = (x: Offer) => x.slot.date + x.slot.startTime;
    const best = new Map<string, Offer>();
    for (const o of offerings ?? []) {
      const slot = slotsByOffering[o.id]?.[0];
      if (!slot || slot.seatsRemaining <= 0) continue;
      const cand: Offer = { offering: o, slot };
      const cur = best.get(o.mentorId);
      const oneToOne = (x: Offer) => (x.offering.capacity <= 1 ? 0 : 1);
      if (!cur || oneToOne(cand) < oneToOne(cur) || (oneToOne(cand) === oneToOne(cur) && when(cand) < when(cur))) best.set(o.mentorId, cand);
    }
    const t = track.toLowerCase();
    const score = (m: MentorDirectoryEntry) => (best.has(m.id) ? 4 : 0) + (t && m.batches.some((b) => b.track.toLowerCase() === t) ? 2 : 0) + (m.avgRating ?? 0) / 5;
    return [...mentors].sort((a, b) => score(b) - score(a)).slice(0, 6).map((m) => ({ mentor: m, offer: best.get(m.id) ?? null }));
  }, [mentors, offerings, slotsByOffering, track]);

  if (mentors !== null && mentors.length === 0) return null;
  return (
    <section aria-label="Mentors for you">
      <div className="flex items-end justify-between gap-3">
        <div>
          <SectionHeading>Mentors for you</SectionHeading>
          <p className="mt-1 px-1 text-[13px] text-foreground/70">Talk to someone who has cleared your exam. Book a one-time session for guidance.</p>
        </div>
        <button type="button" onClick={onSeeAll} className={`${linkAction} shrink-0`}>See all</button>
      </div>
      <ul className="-mx-4 mt-3 flex snap-x snap-mandatory gap-3 overflow-x-auto px-4 pb-2 sm:mx-0 sm:px-0 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
        {mentors === null
          ? [0, 1, 2].map((i) => <li key={i} className="h-60 w-[17.5rem] shrink-0 animate-pulse rounded-3xl bg-foreground/10 lg:w-[19rem]" />)
          : picks.map(({ mentor: m, offer }) => (
              <li key={m.id} className="flex w-[17.5rem] shrink-0 snap-start lg:w-[19rem]">
                <div className="flex w-full flex-col rounded-3xl border border-foreground/15 bg-card p-4 shadow-sm">
                  <Link to="/mentor-profile/$mentorId" params={{ mentorId: m.id }} className="block rounded-2xl">
                    <div className="flex items-center gap-3">
                      <div className="grid h-12 w-12 shrink-0 place-items-center overflow-hidden rounded-full bg-primary/15 font-display text-lg font-bold text-primary">
                        {m.profilePictureUrl ? <img src={m.profilePictureUrl} alt="" loading="lazy" className="h-full w-full object-cover" /> : m.name.charAt(0)}
                      </div>
                      <div className="min-w-0 flex-1">
                        <p className="flex items-center gap-1.5 truncate font-display text-base font-bold text-foreground">{m.name}<BadgeCheck className="h-4 w-4 shrink-0 text-primary" /></p>
                        <p className="truncate text-[13px] text-foreground/70">{m.yearOfStudy || "Mentor"}</p>
                      </div>
                      {m.avgRating !== null && <span className="flex shrink-0 items-center gap-1 rounded-full border border-foreground/20 px-2 py-1 text-xs font-bold"><Star className="h-3 w-3 fill-amber-500 text-amber-500" />{m.avgRating}</span>}
                    </div>
                    {m.aboutText && <p className="mt-3 line-clamp-2 text-[13px] leading-snug text-foreground/70">{m.aboutText}</p>}
                  </Link>
                  <div className="mt-auto pt-4">
                    {offer ? (
                      <div className="rounded-2xl bg-primary/10 p-3">
                        <p className="text-xs font-bold uppercase tracking-wider text-primary">{formatForOffering(offer.offering) === "one_on_one" ? "One-time 1:1 session" : "One-time group session"}</p>
                        <p className="mt-1 truncate text-sm font-bold text-foreground">{offer.offering.title}</p>
                        <p className="truncate text-[13px] text-foreground/70">{offer.offering.durationMinutes} min · {offer.offering.isFree ? "Free" : `₹${offer.offering.price.toLocaleString("en-IN")}`} · {formatSlot(offer.slot.date, offer.slot.startTime)}</p>
                        <button type="button" onClick={() => setBooking(offer)} className="mt-3 inline-flex min-h-11 w-full items-center justify-center rounded-full bg-primary px-4 text-sm font-extrabold text-primary-foreground transition-transform active:scale-[0.98]">Book session</button>
                      </div>
                    ) : (
                      <Link to="/mentor-profile/$mentorId" params={{ mentorId: m.id }} className="inline-flex min-h-11 w-full items-center justify-center gap-1 rounded-full border border-foreground/25 px-4 text-sm font-bold text-foreground transition-colors hover:border-primary">View profile<ChevronRight className="h-4 w-4" /></Link>
                    )}
                  </div>
                </div>
              </li>
            ))}
      </ul>
      {booking && <BookingDialog offering={booking.offering} slot={booking.slot} getToken={getToken} onClose={() => setBooking(null)} onBooked={() => { setBooking(null); onBooked(); }} />}
    </section>
  );
}

function FreeSlotList({ slots, getToken, onBooked }: { slots: { offering: PublicMentorOffering; slot: OpenSlot }[]; getToken: () => Promise<string>; onBooked: () => void }) {
  const [booking, setBooking] = useState<{ offering: PublicMentorOffering; slot: OpenSlot } | null>(null);
  return (
    <>
      <ul className="-mx-2">
        {slots.slice(0, 4).map(({ offering, slot }) => (
          <li key={offering.id}>
            <button type="button" onClick={() => setBooking({ offering, slot })} className="flex min-h-14 w-full items-center gap-3 rounded-2xl px-2 py-2 text-left transition-colors hover:bg-secondary">
              <div className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-primary/15 text-primary"><Gift className="h-4 w-4" /></div>
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-bold">{offering.title}</p>
                <p className="truncate text-[13px] text-foreground/70">{offering.mentorName} · {formatSlot(slot.date, slot.startTime)}</p>
              </div>
              <span className="shrink-0 rounded-full bg-primary px-3 py-1.5 text-xs font-bold text-primary-foreground">Book</span>
            </button>
          </li>
        ))}
      </ul>
      {booking && <BookingDialog offering={booking.offering} slot={booking.slot} getToken={getToken} onClose={() => setBooking(null)} onBooked={() => { setBooking(null); onBooked(); }} />}
    </>
  );
}

function FilterChip({ active, onClick, children }: { active: boolean; onClick: () => void; children: ReactNode }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`inline-flex min-h-10 items-center rounded-full border px-4 text-[13px] font-bold transition-colors ${active ? "border-foreground bg-foreground text-background" : "border-foreground/25 text-foreground/80 hover:border-foreground/50"}`}
    >
      {children}
    </button>
  );
}

function SkeletonGrid() {
  return (
    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
      {[0, 1, 2, 3, 4, 5].map((i) => <div key={i} className="h-72 animate-pulse rounded-3xl bg-secondary" />)}
    </div>
  );
}

function Empty({ text }: { text: string }) {
  return <div className="rounded-3xl border border-dashed border-foreground/25 p-10 text-center text-sm text-foreground/70">{text}</div>;
}

const CARD = "clay group flex flex-col overflow-hidden text-left hover:border-primary";
const CTA = "mt-4 inline-flex min-h-11 items-center justify-center gap-2 rounded-full bg-primary px-5 text-sm font-bold text-primary-foreground transition-all group-hover:gap-3";
const OWNED = "inline-flex items-center gap-1.5 rounded-full bg-emerald-500/10 px-3 py-1 text-xs font-bold text-emerald-700 dark:text-emerald-400";

function fadeUp(i: number) {
  return { initial: { opacity: 0, y: 16 }, animate: { opacity: 1, y: 0 }, transition: { duration: 0.45, delay: Math.min(i, 8) * 0.04, ease: [0.22, 1, 0.36, 1] as const } };
}

// ─── Search ─────────────────────────────────────────────────────────────
function ResultRow({ onClick, icon, title, sub, right }: { onClick: () => void; icon: ReactNode; title: string; sub: string; right?: ReactNode }) {
  return (
    <button type="button" onClick={onClick} className="flex min-h-14 w-full items-center gap-3 rounded-2xl px-3 py-2 text-left transition-colors hover:bg-secondary">
      <div className="grid h-10 w-10 shrink-0 place-items-center overflow-hidden rounded-xl bg-primary/10 text-primary">{icon}</div>
      <div className="min-w-0 flex-1">
        <p className="truncate text-sm font-bold text-foreground">{title}</p>
        <p className="truncate text-[13px] text-foreground/70">{sub}</p>
      </div>
      {right}
      <ChevronRight className="h-4 w-4 shrink-0 text-foreground/70" />
    </button>
  );
}

function SearchResults({ matchedMentors, matchedListings, matchedTests, loading, query }: { query: string; matchedMentors: MentorDirectoryEntry[]; matchedListings: Listing[]; matchedTests: SoldTestEntry[]; loading: boolean }) {
  const navigate = useNavigate();
  const has = matchedMentors.length > 0 || matchedListings.length > 0 || matchedTests.length > 0;
  const Label = ({ children }: { children: ReactNode }) => <p className="mb-1 px-3 text-[11px] font-bold uppercase tracking-wide text-foreground/70">{children}</p>;
  const owned = <span className={OWNED}>Owned</span>;
  return (
    <div className="mt-3 max-h-[28rem] overflow-y-auto rounded-3xl border border-border bg-card p-2">
      {loading ? (
        <div className="flex justify-center py-8"><Loader2 className="h-5 w-5 animate-spin text-foreground/70" /></div>
      ) : !has ? (
        <p className="px-3 py-8 text-center text-sm text-foreground/70">No matches for "{query}".</p>
      ) : (
        <div className="space-y-4 py-2">
          {matchedMentors.length > 0 && (
            <div><Label>Mentors</Label>
              {matchedMentors.map((m) => (
                <ResultRow key={m.id} onClick={() => navigate({ to: "/mentor-profile/$mentorId", params: { mentorId: m.id } })}
                  icon={m.profilePictureUrl ? <img src={m.profilePictureUrl} alt="" className="h-full w-full object-cover" /> : <span className="text-sm font-bold">{m.name.charAt(0)}</span>}
                  title={m.name} sub={[m.yearOfStudy, m.avgRating !== null ? `★ ${m.avgRating}` : ""].filter(Boolean).join(" · ") || "Mentor"} />
              ))}
            </div>
          )}
          {matchedListings.length > 0 && (
            <div><Label>Courses</Label>
              {matchedListings.map((l) => (
                <ResultRow key={`${l.kind}-${l.id}`} onClick={() => navigate({ to: "/course/$kind/$id", params: { kind: l.kind === "Test Series" ? "bundle" : "mentorship", id: l.id } })}
                  icon={l.thumbnailUrl ? <img src={l.thumbnailUrl} alt="" className="h-full w-full object-cover" /> : l.kind === "Test Series" ? <BookOpen className="h-4 w-4" /> : <Users2 className="h-4 w-4" />}
                  title={l.title} sub={`${EXAM_LABELS[l.exam]} · ${l.kind} · ${l.track || "All tracks"}`} right={l.purchased ? owned : undefined} />
              ))}
            </div>
          )}
          {matchedTests.length > 0 && (
            <div><Label>Individual tests</Label>
              {matchedTests.map((t) => (
                <ResultRow key={t.id} onClick={() => navigate({ to: "/sold-test/$id", params: { id: t.id } })} icon={<Tag className="h-4 w-4" />}
                  title={t.name} sub={`By ${t.mentorName}`} right={t.purchased ? owned : <span className="shrink-0 text-xs font-bold">₹{t.price}</span>} />
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// ─── Grids ──────────────────────────────────────────────────────────────
const GRID = "grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3";

function ListingGrid({ listings, loading, emptyText, showKindBadge }: { listings: Listing[]; loading: boolean; emptyText: string; showKindBadge?: boolean }) {
  if (loading) return <SkeletonGrid />;
  if (listings.length === 0) return <Empty text={emptyText} />;
  return <div className={GRID}>{listings.map((l, i) => <ListingCard key={`${l.kind}-${l.id}`} listing={l} index={i} showKindBadge={showKindBadge} />)}</div>;
}

function SoldTestGrid({ tests }: { tests: SoldTestEntry[] | null }) {
  if (tests === null) return <SkeletonGrid />;
  if (tests.length === 0) return <Empty text="No individual tests available yet." />;
  return <div className={GRID}>{tests.map((t, i) => <SoldTestCard key={t.id} test={t} index={i} />)}</div>;
}

function MentorGrid({ mentors }: { mentors: MentorDirectoryEntry[] | null }) {
  if (mentors === null) return <SkeletonGrid />;
  if (mentors.length === 0) return <Empty text="No mentors listed yet." />;
  return <div className={GRID}>{mentors.map((m, i) => <MentorCard key={m.id} mentor={m} index={i} />)}</div>;
}

// ─── Cards (the whole card is one tap target) ───────────────────────────
function ListingCard({ listing, index = 0, showKindBadge }: { listing: Listing; index?: number; showKindBadge?: boolean }) {
  const navigate = useNavigate();
  const MetaIcon = listing.metaIcon;
  const Icon = listing.kind === "Test Series" ? BookOpen : Users2;
  return (
    <motion.button {...fadeUp(index)} type="button" className={`${CARD} h-full`} onClick={() => navigate({ to: "/course/$kind/$id", params: { kind: listing.kind === "Test Series" ? "bundle" : "mentorship", id: listing.id } })}>
      <div className="relative grid aspect-[16/9] w-full place-items-center overflow-hidden bg-secondary">
        {listing.thumbnailUrl ? <img src={listing.thumbnailUrl} alt="" loading="lazy" className="h-full w-full object-cover" /> : <Icon className="h-10 w-10 text-primary/40" strokeWidth={1.4} />}
        <span className="absolute left-3 top-3 rounded-full bg-background/95 px-2.5 py-1 text-[11px] font-bold text-foreground">{EXAM_LABELS[listing.exam]}</span>
        {showKindBadge && <span className="absolute right-3 top-3 rounded-full bg-foreground px-2.5 py-1 text-[11px] font-bold text-background">{listing.kind}</span>}
      </div>
      <div className="flex w-full flex-1 flex-col p-4">
        <h3 className="line-clamp-2 font-display text-lg font-bold leading-snug tracking-tight text-foreground">{listing.title}</h3>
        <p className="mt-2 flex items-center gap-1.5 text-[13px] text-foreground/70"><MetaIcon className="h-3.5 w-3.5 shrink-0" /><span className="truncate">{listing.metaLine}</span><span className="ml-auto shrink-0 rounded-full border border-border px-2 py-0.5 font-bold">{listing.track || "All"}</span></p>
        <div className="mt-4 flex flex-wrap items-baseline gap-x-2">
          {listing.purchased ? (
            <span className={OWNED}><BadgeCheck className="h-3.5 w-3.5" />You're in</span>
          ) : listing.sellingPrice === 0 ? (
            <span className="font-display text-xl font-extrabold text-primary">Free</span>
          ) : (
            <>
              <span className="font-display text-xl font-extrabold text-foreground">₹{listing.sellingPrice.toLocaleString()}</span>
              {listing.crossedPrice > listing.sellingPrice && <span className="text-sm text-foreground/70 line-through">₹{listing.crossedPrice.toLocaleString()}</span>}
              {listing.discountPercent > 0 && <span className="text-xs font-bold text-emerald-700 dark:text-emerald-400">{listing.discountPercent}% off</span>}
            </>
          )}
        </div>
        <span className={CTA}>{listing.purchased ? "Study now" : listing.sellingPrice === 0 ? "Get for free" : "Buy now"}<ArrowRight className="h-4 w-4" /></span>
      </div>
    </motion.button>
  );
}

function SoldTestCard({ test, index = 0 }: { test: SoldTestEntry; index?: number }) {
  const navigate = useNavigate();
  return (
    <motion.button {...fadeUp(index)} type="button" className={`${CARD} h-full`} onClick={() => navigate({ to: "/sold-test/$id", params: { id: test.id } })}>
      <div className="grid aspect-[16/9] w-full place-items-center bg-secondary"><ClipboardList className="h-10 w-10 text-primary/40" strokeWidth={1.4} /></div>
      <div className="flex w-full flex-1 flex-col p-4">
        <h3 className="line-clamp-2 font-display text-lg font-bold leading-snug tracking-tight text-foreground">{test.name}</h3>
        <p className="mt-2 truncate text-[13px] text-foreground/70">By {test.mentorName} · {test.totalQuestions}Q · {test.durationMinutes}m</p>
        <div className="mt-4">{test.purchased ? <span className={OWNED}><BadgeCheck className="h-3.5 w-3.5" />You're in</span> : <span className="font-display text-xl font-extrabold">₹{test.price.toLocaleString()}</span>}</div>
        <span className={CTA}>{test.purchased ? "Start test" : "Buy now"}<ArrowRight className="h-4 w-4" /></span>
      </div>
    </motion.button>
  );
}

function MentorCard({ mentor, index = 0 }: { mentor: MentorDirectoryEntry; index?: number }) {
  return (
    <motion.div {...fadeUp(index)} className="h-full">
      <Link to="/mentor-profile/$mentorId" params={{ mentorId: mentor.id }} className={`${CARD} h-full p-5`}>
        <div className="flex items-center gap-3">
          <div className="grid h-14 w-14 shrink-0 place-items-center overflow-hidden rounded-full bg-primary/10 font-display text-lg font-bold text-primary">
            {mentor.profilePictureUrl ? <img src={mentor.profilePictureUrl} alt="" loading="lazy" className="h-full w-full object-cover" /> : mentor.name.charAt(0)}
          </div>
          <div className="min-w-0 flex-1">
            <p className="flex items-center gap-1.5 truncate font-display text-base font-bold text-foreground">{mentor.name}<BadgeCheck className="h-4 w-4 shrink-0 text-primary" /></p>
            {mentor.yearOfStudy && <p className="flex items-center gap-1 truncate text-[13px] text-foreground/70"><GraduationCap className="h-3 w-3 shrink-0" />{mentor.yearOfStudy}</p>}
          </div>
          {mentor.avgRating !== null && <span className="flex shrink-0 items-center gap-1 rounded-full border border-border px-2 py-1 text-xs font-bold"><Star className="h-3 w-3 fill-amber-500 text-amber-500" />{mentor.avgRating}</span>}
        </div>
        {mentor.aboutText && <p className="mt-4 line-clamp-2 text-sm text-foreground/70">{mentor.aboutText}</p>}
        <div className="mt-auto flex items-center justify-between pt-5">
          <span className="text-xs font-bold text-foreground/70">{mentor.batches.length} batch{mentor.batches.length === 1 ? "" : "es"}</span>
          <span className="inline-flex items-center gap-1 text-sm font-bold text-primary transition-all group-hover:gap-2">View profile<ChevronRight className="h-4 w-4" /></span>
        </div>
      </Link>
    </motion.div>
  );
}