import { createFileRoute, Link, Await } from "@tanstack/react-router";
import { pageHead, SITE_URL } from "@/lib/seo";
import { Suspense, lazy, useEffect, useRef, useState, type ReactNode, type RefObject } from "react";
import {
  IconMenu2 as Menu,
  IconX as X,
  IconDeviceDesktopAnalytics as MonitorPlay,
  IconLayoutDashboard as LayoutDashboard,
  IconCalendarCheck as CalendarCheck,
  IconChartLine as LineChart,
  IconArrowRight as ArrowRight,
  IconSparkles as Sparkles,
  IconUserCheck as UserCheck,
  IconTarget as Target,
  IconActivity as Activity,
  IconTrendingUp as TrendingUp,
  IconShieldCheck as ShieldCheck,
  IconUsers as Users,
  IconWorld as Globe,
  IconBrandLinkedin as Linkedin,
  IconBrandYoutube as Youtube,
  IconBrandInstagram as Instagram,
  IconBrandX as Twitter,
  IconMessageCircle as MessageSquare,
  IconAt as AtSign,
  IconAward as Award,
  IconStack2 as Layers3,
  IconChevronDown as ChevronDown,
  IconSchool as GraduationCap, // FIX: replaced the separate `lucide-react` import.
  // Pulling in an entire second icon library for one icon was adding a whole
  // extra module (and its own tree-shaking boundary) to the bundle for a
  // single glyph. Tabler ships an equivalent "school" icon, so we use that
  // instead and drop the lucide-react dependency from this file entirely.
  IconBriefcase as Briefcase,
} from "@tabler/icons-react";
import { listMentorsForLanding } from "@/server-functions/catalog";
import { listPublishedPosts } from "@/server-functions/blog-public";
import { BLOG_CATEGORY_LABELS } from "@/lib/blog-types";
import type { PublicBlogPostSummary } from "@/lib/blog-types";
import { MotionConfig, motion, useMotionValueEvent, useScroll } from "motion/react";
import { HeroMotion, PREMIUM_BTN, GHOST_BTN } from "@/components/landing/HeroMotion";
import { LandingFreeSessionsSection } from "@/components/landing-free-sessions-section";
import { LandingProSection } from "@/components/landing-pro-section";
import { DiwaliSaleSection } from "@/components/diwali/diwali-sale-section";
import { FreeResourcesSection } from "@/components/landing/free-resources-section";
import { QuickMockSection } from "@/components/landing/quick-mock-section";
import { DEMO_EXAM_KEYS, EXAM_DEMOS, toneOf } from "@/components/landing/exam-demos";
import { LANDING_FAQS, LANDING_LAST_UPDATED } from "@/components/landing/landing-faq";
import { usePreferredExam } from "@/components/landing/use-preferred-exam";
import { useAuth } from "@/lib/auth-context";
import { TOOLS } from "@/lib/tools-list";
import { JEE_MAIN_2027, NEET_UG_2027, daysBetween, todayIST } from "@/lib/exam-dates";
import { RELEASES, formatReleaseDate } from "@/lib/whats-new";
import { track, trackOnce } from "@/lib/analytics";
import { captureReferralFromUrl } from "@/lib/referral-client";
import { IconPlus as Plus } from "@tabler/icons-react";

// FIX: CbtSimulator is a heavy, below-the-fold interactive component
// (exam-navigation UI, question palette, timers, etc). It was being bundled
// into the initial JS payload even though nothing above the fold needs it.
// Lazy-loading it moves its code (and whatever libraries it pulls in) out of
// the critical bundle, which is what Lighthouse's "Reduce unused JavaScript"
// audit was flagging on /assets/index-*.js.
const CbtSimulator = lazy(() =>
  import("@/components/landing/CbtSimulator").then((m) => ({ default: m.CbtSimulator })),
);

// ---------------------------------------------
// Mentor data is deferred/streamed rather than awaited in the loader.
// Awaiting the DB call here would block the ENTIRE page — including the
// hero, which has nothing to do with mentors — until the mentor query
// resolves (this is what caused the FCP/Speed Index regression after the
// first loader-based fix). Instead we hand back the raw promise; the page
// shell streams to the browser immediately, and MentorShowcase below
// resolves the promise itself via <Await>, with a real static fallback
// (not a spinner) shown until it settles. This keeps FCP/LCP fast AND
// keeps mentor content out of a client-only useEffect, so it's still
// present in the streamed HTML rather than hidden behind a client fetch.
// ---------------------------------------------
export const Route = createFileRoute("/")({
  // Title/description stay short on purpose — Google truncates past ~60/
  // ~160 chars, so this is not where the "in depth" story goes. Real depth
  // (the problem, the product, the team) lives on /about, and this WebPage
  // node just points at it rather than duplicating the Organization/
  // WebSite nodes __root.tsx already sets for every page.
  head: () =>
    pageHead({
      title: "NEET & JEE CBT Practice + Mentors | Edurack",
      rawTitle: true,
      path: "/",
      description:
        "Exam-format CBT mocks and previous year questions with detailed solutions for NEET and JEE, plus mentors who cleared the exam. Free to start.",
      jsonLd: landingJsonLd(),
    }),
  loader: () => {
    return {
      mentorsPromise: listMentorsForLanding().then(
        (res) => res.mentors as LandingMentor[],
      ),
      // Same streamed-promise pattern as mentors above: the homepage shell
      // ships immediately and the blog rail resolves in behind it, rather
      // than blocking FCP on a Mongo round trip nothing above the fold needs.
      postsPromise: listPublishedPosts({ data: { page: 1 } }).then(
        (res) => res.posts.slice(0, 3),
      ),
    };
  },
  component: Index,
});

// ---------------------------------------------
// Launch date — single source of truth so the hero badge, footer, and
// structured data all agree with each other.
// ---------------------------------------------
const LAUNCH_DATE_LABEL = "Launched 10 September 2026";

// ---------------------------------------------
// Structured data, rendered into the server HTML (so crawlers and AI answer engines that don't run
// JavaScript still see it). The Organization/WebSite nodes live in __root.tsx; the Organization node
// here shares its @id and only ADDS the founder/founding details, so there is one Edurack entity.
// ---------------------------------------------
const LANDING_FOUNDERS = [
  { name: "Vishal Sharma", linkedin: "https://www.linkedin.com/in/vishal-sharma-a59bb2370/" },
  { name: "Tarun Yadav", linkedin: "https://www.linkedin.com/in/tarun-yadav-37094337b/" },
  { name: "Archita Priyadarshinee", linkedin: "https://www.linkedin.com/in/archita-priyadarshinee-behuria-a01323335/" },
];

function landingJsonLd() {
  const org = { "@id": `${SITE_URL}/#organization` };
  return [
    {
      "@context": "https://schema.org",
      "@type": "WebPage",
      "@id": `${SITE_URL}/#webpage`,
      url: `${SITE_URL}/`,
      name: "NEET & JEE CBT Practice + Mentors | Edurack",
      inLanguage: "en-IN",
      datePublished: "2026-09-10",
      dateModified: LANDING_LAST_UPDATED,
      isPartOf: { "@id": `${SITE_URL}/#website` },
      about: org,
      mainEntity: org,
      // The pages a crawler should treat as part of this site's core: tools, release notes and the FAQ.
      significantLink: [`${SITE_URL}/tools`, `${SITE_URL}/tools/jee-main-percentile-calculator`, `${SITE_URL}/tools/jee-main-countdown`, `${SITE_URL}/tools/neet-countdown`, `${SITE_URL}/whats-new`, `${SITE_URL}/faq`],
    },
    {
      "@context": "https://schema.org",
      "@type": "EducationalOrganization",
      "@id": `${SITE_URL}/#organization`,
      alternateName: "EDURACK.IN",
      foundingDate: "2026-09-10",
      founder: LANDING_FOUNDERS.map((f) => ({ "@type": "Person", name: f.name, jobTitle: "Co-Founder", sameAs: [f.linkedin] })),
    },
    {
      "@context": "https://schema.org",
      "@type": "WebApplication",
      "@id": `${SITE_URL}/#cbt-simulator`,
      name: "Edurack CBT Simulator",
      url: `${SITE_URL}/simulator/live`,
      description: "A free computer-based-test interface built to match the NTA exam screen, for NEET and JEE practice.",
      applicationCategory: "EducationalApplication",
      operatingSystem: "Any (web browser)",
      inLanguage: "en-IN",
      isAccessibleForFree: true,
      offers: { "@type": "Offer", price: "0", priceCurrency: "INR" },
      publisher: org,
    },
    {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      "@id": `${SITE_URL}/#faq`,
      isPartOf: { "@id": `${SITE_URL}/#webpage` },
      mainEntity: LANDING_FAQS.map((f) => ({ "@type": "Question", name: f.q, acceptedAnswer: { "@type": "Answer", text: f.a } })),
    },
  ];
}

// ---------------------------------------------
// Shared CTA styling — a stronger gradient pill used for the header's
// primary Sign Up action and the hero's primary CTA, so the single most
// important action on the page reads as clearly more important than the
// generic `clay-btn` used everywhere else (tab pills, ghost links, etc).
// Reuses the same sky→teal gradient already established in the mentor
// marketplace banner further down the page, rather than introducing a
// new color.
// ---------------------------------------------
const PRIMARY_CTA = PREMIUM_BTN;

// ---------------------------------------------
// Exam config
// ---------------------------------------------
type ExamKey = "neet" | "jee" | "cuet" | "ipmat";

const exams: { key: ExamKey; label: string; full: string }[] = [
  { key: "neet", label: "NEET", full: "NEET (Medical)" },
  { key: "jee", label: "JEE", full: "JEE Main & Advanced" },
  { key: "cuet", label: "CUET", full: "CUET (UG)" },
  { key: "ipmat", label: "IPMAT", full: "IPMAT (IIM)" },
];

// Honest trust signals for the hero — real product facts, not invented
// numbers. Reuses ShieldCheck / Users / Globe, which were imported but
// previously unused anywhere in this file.
const heroTrustPoints = [
  { icon: ShieldCheck, text: "Exam-accurate CBT interface" },
  { icon: Users, text: "Mentors who've actually cleared these exams" },
  { icon: Globe, text: "Built for NEET · JEE" },
];

// ---------------------------------------------
// Scroll-reveal motion device
// ---------------------------------------------
function Reveal({
  children,
  delay = 0,
  className = "",
}: {
  children: ReactNode;
  delay?: number;
  className?: string;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const node = ref.current;
    if (!node) return;

    const prefersReduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (prefersReduced) {
      setVisible(true);
      return;
    }

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.15, rootMargin: "0px 0px -40px 0px" },
    );
    observer.observe(node);
    return () => observer.disconnect();
  }, []);

  return (
    <div
      ref={ref}
      className={`transition-all duration-700 ease-out ${
        visible ? "translate-y-0 opacity-100" : "translate-y-6 opacity-0"
      } ${className}`}
      style={{ transitionDelay: visible ? `${delay}ms` : "0ms" }}
    >
      {children}
    </div>
  );
}

// ---------------------------------------------
// Navigation config
// ---------------------------------------------
type NavLink =
  | { label: string; type: "anchor"; href: string }
  | { label: string; type: "route"; to: string };

const navLinks: NavLink[] = [
  { label: "CBT Simulator", type: "anchor", href: "#simulator" },
  { label: "Mentors", type: "anchor", href: "#mentors" },
  { label: "Features", type: "anchor", href: "#features" },
  { label: "Why Edurack", type: "anchor", href: "#about" },
  { label: "Connect", type: "anchor", href: "#connect" },
  { label: "Join as Mentor", type: "anchor", href: "#marketplace" },
  { label: "NEET Weightage", type: "route", to: "/neet/chapter-wise-weightage" },
  { label: "JEE Weightage", type: "route", to: "/jee/chapter-wise-weightage" },
  { label: "Mentor Sessions", type: "route", to: "/mentorship-sessions" },
  { label: "Blog", type: "route", to: "/blog" },
  { label: "Contact", type: "route", to: "/contact" },
  { label: "Free Tools", type: "route", to: "/tools" },
  { label: "What's New", type: "route", to: "/whats-new" },
];

// ---------------------------------------------
// Social Links Configuration
// ---------------------------------------------
const socialLinks = [
  {
    name: "LinkedIn",
    description: "Founder updates & corporate networking",
    href: "https://www.linkedin.com/company/edurack",
    icon: Linkedin,
    color: "text-blue-600 dark:text-blue-400",
    bg: "bg-blue-500/10",
  },
  {
    name: "Threads",
    description: "Real-time updates & platform discussions",
    href: "https://threads.net/@edurack.in",
    icon: AtSign,
    color: "text-slate-900 dark:text-slate-100",
    bg: "bg-slate-500/10",
  },
  {
    name: "YouTube",
    description: "CBT walkthroughs & strategy guides",
    href: "https://youtube.com/@edurack",
    icon: Youtube,
    color: "text-red-600 dark:text-red-400",
    bg: "bg-red-500/10",
  },
  {
    name: "Instagram",
    description: "Student updates & mentor reels",
    href: "https://instagram.com/edurack.in",
    icon: Instagram,
    color: "text-pink-600 dark:text-pink-400",
    bg: "bg-pink-500/10",
  },
  {
    name: "X (Twitter)",
    description: "Tech announcements & build updates",
    href: "https://x.com/edurack_",
    icon: Twitter,
    color: "text-sky-500 dark:text-sky-400",
    bg: "bg-sky-500/10",
  },
  {
    name: "Reddit",
    description: "Community strategy & discussions",
    href: "https://www.reddit.com/user/Edurack/",
    icon: MessageSquare,
    color: "text-orange-600 dark:text-orange-400",
    bg: "bg-orange-500/10",
  },
];

function Index() {
  const ctaRef = useRef<HTMLDivElement>(null);
  // Favicon links. (The Organization JSON-LD used to be injected here, client-side only; it is now
  // server-rendered from landingJsonLd() so crawlers that skip JavaScript can read it.)
  useEffect(() => {
    // 2. Dynamic Favicon Link Injection
    const faviconIco = document.createElement("link");
    faviconIco.rel = "icon";
    faviconIco.type = "image/x-icon";
    faviconIco.href = "https://www.edurack.in/favicon.ico";
    document.head.appendChild(faviconIco);

    const faviconPng = document.createElement("link");
    faviconPng.rel = "icon";
    faviconPng.type = "image/png";
    faviconPng.setAttribute("sizes", "48x48");
    faviconPng.href = "https://www.edurack.in/favicon-48x48.png";
    document.head.appendChild(faviconPng);

    // Cleanup when component unmounts
    return () => {
      document.head.removeChild(faviconIco);
      document.head.removeChild(faviconPng);
    };
  }, []);

  // A friend's invite link (/?ref=CODE): remember the code until they sign up.
  useEffect(() => {
    captureReferralFromUrl();
  }, []);

  // How far down the page people get (25/50/75/100%), once each per visit. This is the number to watch
  // when changing the page: it shows which section loses visitors.
  useEffect(() => {
    let ticking = false;
    const onScroll = () => {
      if (ticking) return;
      ticking = true;
      requestAnimationFrame(() => {
        ticking = false;
        const max = document.documentElement.scrollHeight - window.innerHeight;
        if (max <= 0) return;
        const pct = (window.scrollY / max) * 100;
        for (const mark of [25, 50, 75, 100]) {
          if (pct >= (mark === 100 ? 98 : mark)) trackOnce(`landing-scroll-${mark}`, "landing_scroll_depth", { depth: mark });
        }
      });
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <MotionConfig reducedMotion="user">
      <div className="min-h-screen bg-background pb-24 md:pb-0">
        <Header />
        <main>
          <HeroMotion ctaRef={ctaRef} />
          <DiwaliSaleSection />
          <AnswerSection />
          <ExamsSection />
          <ToolsSection />
          <QuickMockSection />
          <LandingFreeSessionsSection />
          <LoopSection />
          <SimulatorSection />
          <MentorShowcase />
          <FeaturesSection />
          <LandingProSection />
          <BlogShowcase />
          <FreeResourcesSection />
          <FaqSection />
          <WhatsNewSection />
          <MentorBanner />
          <CareersStrip />
          <FinalCta />
        </main>
        <Footer />
        <MobileDock ctaRef={ctaRef} />
      </div>
    </MotionConfig>
  );
}

const EASE = [0.22, 1, 0.36, 1] as const;
const INK = "bg-[#141b2b] text-white";
const WRAP = "mx-auto max-w-6xl px-4 sm:px-6";

function Rise({ children, delay = 0, className = "" }: { children: ReactNode; delay?: number; className?: string }) {
  return (
    <motion.div
      className={className}
      initial={{ opacity: 0, y: 28 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-70px" }}
      transition={{ duration: 0.7, delay, ease: EASE }}
    >
      {children}
    </motion.div>
  );
}

function Title({ light, bold, dark = false }: { light: string; bold: string; dark?: boolean }) {
  return (
    <h2 className={`font-display text-4xl leading-[1.05] tracking-tight sm:text-5xl ${dark ? "text-white" : "text-foreground"}`}>
      <span className="block font-light">{light}</span>
      <span className="block font-extrabold">{bold}</span>
    </h2>
  );
}

const shownNav = navLinks.filter((l) => ["Mentors", "Features", "Join as Mentor", "Mentor Sessions", "Blog", "Contact"].includes(l.label));

// Two more links that fit in the header from the xl breakpoint up; the mobile menu always shows them.
const extraNav = navLinks.filter((l) => ["Free Tools", "What's New"].includes(l.label));

function NavItem({ link, onClick, extraClass = "" }: { link: NavLink; onClick?: () => void; extraClass?: string }) {
  const cls = `inline-flex min-h-11 items-center whitespace-nowrap rounded-full px-4 text-sm font-semibold text-foreground/70 transition-colors hover:text-foreground lg:px-3 xl:px-4 ${extraClass}`;
  return link.type === "route" ? (
    <Link to={link.to} onClick={onClick} className={cls}>{link.label}</Link>
  ) : (
    <a href={link.href} onClick={onClick} className={cls}>{link.label}</a>
  );
}

function Header() {
  const [open, setOpen] = useState(false);
  const { user } = useAuth(); // null until Firebase resolves, so the server HTML and first paint match
  return (
    <header className="sticky top-0 z-50 border-b border-border bg-background/80 backdrop-blur-xl" style={{ paddingTop: "env(safe-area-inset-top)" }}>
      <div className={`${WRAP} flex h-16 items-center justify-between gap-2`}>
        <Link to="/" className="flex items-center gap-2">
          <img src="/edurack-logo.webp" alt="EDURACK" width={160} height={160} className="h-9 w-auto object-contain" />
          <span className="font-display text-xl font-extrabold tracking-tight text-foreground max-[350px]:hidden">edurack</span>
        </Link>
        <nav className="hidden items-center lg:flex">
          {shownNav.map((l) => <NavItem key={l.label} link={l} />)}
          {extraNav.map((l) => <NavItem key={l.label} link={l} extraClass="max-xl:hidden" />)}
        </nav>
        <div className="flex shrink-0 items-center gap-1">
          {user ? (
            <Link to="/dashboard" className={`${PREMIUM_BTN} !min-h-11 !shrink-0 whitespace-nowrap !px-4 text-sm sm:!px-5`}>
              Dashboard
            </Link>
          ) : (
            <>
              <Link
                to="/auth"
                search={{ tab: "signin" }}
                className="inline-flex min-h-11 shrink-0 items-center whitespace-nowrap rounded-full px-2.5 text-sm font-bold text-foreground/80 hover:text-foreground max-[360px]:hidden sm:px-3.5"
              >
                Log in
              </Link>
              <Link
                to="/auth"
                search={{ tab: "signup" }}
                className={`${PREMIUM_BTN} !min-h-11 !shrink-0 whitespace-nowrap !px-4 text-sm sm:!px-5`}
              >
                Sign up
              </Link>
            </>
          )}
          <button className="grid h-11 w-11 shrink-0 place-items-center rounded-full active:scale-90 lg:hidden" onClick={() => setOpen(!open)} aria-label="Menu" aria-expanded={open}>
            {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </div>
      <div className={`overflow-hidden border-border transition-all duration-300 lg:hidden ${open ? "max-h-96 border-t" : "max-h-0"}`}>
        <nav className={`${WRAP} flex flex-col py-2`}>
          {[...shownNav, ...extraNav].map((l) => <NavItem key={l.label} link={l} onClick={() => setOpen(false)} />)}
        </nav>
      </div>
    </header>
  );
}

function MobileDock({ ctaRef }: { ctaRef: RefObject<HTMLDivElement | null> }) {
  const [show, setShow] = useState(false);
  const { user } = useAuth();
  useEffect(() => {
    const node = ctaRef.current;
    if (!node) return;
    const io = new IntersectionObserver(([e]) => setShow(!e.isIntersecting && e.boundingClientRect.top < 0));
    io.observe(node);
    return () => io.disconnect();
  }, [ctaRef]);
  return (
    <div
      className={`fixed inset-x-0 bottom-0 z-40 border-t border-border bg-background/90 px-3 pt-2 backdrop-blur-xl transition-transform duration-300 md:hidden ${show ? "translate-y-0" : "translate-y-full"}`}
      style={{ paddingBottom: "max(0.75rem, env(safe-area-inset-bottom))" }}
    >
      {user ? (
        <Link to="/dashboard" className={PREMIUM_BTN}>Go to your dashboard</Link>
      ) : (
        <div className="grid grid-cols-[1fr_1.5fr] gap-2">
          <Link to="/auth" search={{ tab: "signin" }} className={GHOST_BTN}>Log in</Link>
          <Link to="/auth" search={{ tab: "signup" }} className={PREMIUM_BTN}>Start free</Link>
        </div>
      )}
    </div>
  );
}

// ── Prep loop: scroll-linked, mirrors the carousel ─────────────────────────
const loop = [
  { k: "Practice", d: "Exam-format tests that feel like the real paper, not a worksheet." },
  { k: "Analyse", d: "Accuracy, speed and concept gaps: the story behind the score." },
  { k: "Get guided", d: "Mentors who have written the same exam and know what to cut." },
  { k: "Improve", d: "Fix the two things that matter, then test again, sharper." },
];

function LoopSection() {
  const ref = useRef<HTMLDivElement>(null);
  const [active, setActive] = useState(0);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start 0.75", "end 0.55"] });
  useMotionValueEvent(scrollYProgress, "change", (v) => setActive(Math.max(0, Math.min(3, Math.floor(v * 4)))));

  return (
    <section className={`${INK} py-20 sm:py-28`}>
      <div className={`${WRAP} grid gap-12 lg:grid-cols-[.9fr_1.1fr]`}>
        <div className="lg:sticky lg:top-28 lg:self-start">
          <Rise>
            <p className="text-lg text-white/60">We don't think prep should be</p>
            <p className="mt-2 font-display text-xl font-bold text-white/40 line-through decoration-white/40">Study → Mock → Score → Repeat</p>
            <h2 className="mt-8 font-display text-5xl leading-[1.02] tracking-tight sm:text-6xl">
              <span className="block font-light">This is</span>
              <span className="block font-extrabold">Edurack.</span>
            </h2>
            <p className="mt-5 max-w-sm text-white/60">Four steps, one place, built for people who want direction and not just another mock.</p>
          </Rise>
        </div>

        <div ref={ref} className="relative pl-8 sm:pl-10">
          <div className="absolute bottom-2 left-[7px] top-2 w-px bg-white/15" />
          <motion.div className="absolute left-[7px] top-2 w-px origin-top bg-[#7ba4f0]" style={{ scaleY: scrollYProgress, bottom: "0.5rem" }} />
          {loop.map((s, i) => (
            <div key={s.k} className="relative py-7 transition-opacity duration-500" style={{ opacity: i <= active ? 1 : 0.32 }}>
              <span className={`absolute -left-8 top-[2.15rem] h-[15px] w-[15px] rounded-full border-2 transition-colors duration-500 sm:-left-10 ${i <= active ? "border-[#7ba4f0] bg-[#7ba4f0]" : "border-white/30 bg-[#141b2b]"}`} />
              <span aria-hidden className="pointer-events-none absolute -top-2 right-0 select-none font-display text-8xl font-extrabold text-white/[0.05] sm:text-9xl">0{i + 1}</span>
              <h3 className="font-display text-3xl font-extrabold tracking-tight sm:text-4xl">{s.k}</h3>
              <p className="mt-2 max-w-md text-base leading-relaxed text-white/60">{s.d}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// ── Answer-first block: what Edurack is, in plain words (read by people, search snippets and AI answers) ──
const atAGlance: { k: string; v: ReactNode }[] = [
  { k: "Live now", v: "NEET and JEE (CUET and IPMAT coming soon)" },
  { k: "Start free", v: <Link to="/simulator/live" className="font-semibold text-primary hover:underline">CBT demo, no sign-up needed</Link> },
  { k: "Practise", v: <Link to="/pyq" search={{ exam: "neet" }} className="font-semibold text-primary hover:underline">Previous year questions, chapter and topic wise</Link> },
  { k: "Mentors", v: <Link to="/mentorship-sessions" className="font-semibold text-primary hover:underline">Independent mentors who verify their rank and credentials</Link> },
  { k: "Launched", v: "10 September 2026" },
];

function AnswerSection() {
  return (
    <section id="what-is-edurack" aria-labelledby="what-is-edurack-heading" className="py-14 sm:py-20">
      <div className={`${WRAP} grid gap-8 lg:grid-cols-[1.1fr_.9fr] lg:items-start`}>
        <Rise className="min-w-0">
          <h2 id="what-is-edurack-heading" className="font-display text-3xl leading-[1.1] tracking-tight text-foreground sm:text-4xl">
            <span className="font-light">What is </span>
            <span className="font-extrabold">Edurack?</span>
          </h2>
          <p className="mt-5 text-lg leading-relaxed text-foreground/80">
            Edurack is an exam-preparation platform for Indian aspirants. It combines a CBT simulator built to match the real NTA exam screen,
            chapter-wise previous year questions with step-by-step solutions, and mentors who have cleared the exam. NEET and JEE are live
            today; CUET and IPMAT are coming soon.
          </p>
          <Link to="/about" className="mt-4 inline-flex min-h-11 items-center gap-1.5 text-sm font-bold text-primary">
            More about Edurack <ArrowRight className="h-4 w-4" />
          </Link>
        </Rise>
        <Rise delay={0.08} className="min-w-0">
          <dl className="grid gap-px overflow-hidden rounded-3xl border border-border bg-border text-sm">
            {atAGlance.map((r) => (
              <div key={r.k} className="flex gap-4 bg-card p-4">
                <dt className="w-24 shrink-0 font-bold text-muted-foreground">{r.k}</dt>
                <dd className="min-w-0 text-foreground">{r.v}</dd>
              </div>
            ))}
          </dl>
        </Rise>
      </div>
    </section>
  );
}

// ── FAQ: native <details>, so every answer is in the HTML for crawlers and works without JavaScript ──
function FaqSection() {
  return (
    <section id="faq" aria-labelledby="faq-heading" className="py-16 sm:py-24">
      <div className={`${WRAP} grid gap-10 lg:grid-cols-[.8fr_1.2fr]`}>
        <Rise className="min-w-0 lg:sticky lg:top-28 lg:self-start">
          <h2 id="faq-heading" className="font-display text-4xl leading-[1.05] tracking-tight text-foreground sm:text-5xl">
            <span className="block font-light">Questions,</span>
            <span className="block font-extrabold">answered.</span>
          </h2>
          <p className="mt-4 text-muted-foreground">Straight answers before you sign up.</p>
          <div className="mt-6 flex flex-col gap-3 sm:flex-row lg:flex-col">
            <Link to="/simulator/live" className={PREMIUM_BTN}>Try the free CBT demo <ArrowRight className="h-4 w-4" /></Link>
            <Link to="/faq" className={GHOST_BTN}>All FAQs</Link>
          </div>
        </Rise>
        <div className="min-w-0 divide-y divide-border rounded-3xl border border-border bg-card">
          {LANDING_FAQS.map((f, i) => (
            <details
              key={f.q}
              className="group p-5 sm:p-6"
              onToggle={(e) => {
                if ((e.currentTarget as HTMLDetailsElement).open) track("landing_faq_opened", { index: i });
              }}
            >
              <summary className="flex min-h-11 cursor-pointer list-none items-center justify-between gap-4 [&::-webkit-details-marker]:hidden">
                <h3 className="text-base font-bold text-foreground">{f.q}</h3>
                <Plus className="h-5 w-5 shrink-0 text-muted-foreground transition-transform group-open:rotate-45" />
              </summary>
              <p className="mt-3 leading-relaxed text-muted-foreground">{f.a}</p>
            </details>
          ))}
        </div>
      </div>
    </section>
  );
}

// ── Free tools: always one click from the homepage ──
function ToolsSection() {
  // Days to go, worked out from today's date in India. Rendered into the HTML, so it is fresh for crawlers and for people.
  const today = todayIST();
  const jeeDays = daysBetween(today, JEE_MAIN_2027.session1.first);
  const neetDays = daysBetween(today, NEET_UG_2027.planningDate);
  const chip = "inline-flex min-h-11 items-center gap-2 rounded-full border border-border bg-card px-4 text-sm font-semibold text-foreground hover:border-primary";
  return (
    <section id="tools" aria-labelledby="tools-heading" className="py-14 sm:py-20">
      <div className={WRAP}>
        <Rise className="max-w-2xl">
          <h2 id="tools-heading" className="font-display text-4xl leading-[1.05] tracking-tight text-foreground sm:text-5xl">
            <span className="block font-light">Free tools</span>
            <span className="block font-extrabold">for NEET and JEE.</span>
          </h2>
          <p className="mt-5 text-lg leading-relaxed text-muted-foreground">Rank and percentile calculators, exam countdowns and a study plan. No sign-up needed.</p>
        </Rise>
        <div className="mt-6 flex flex-wrap gap-3">
          {jeeDays > 0 && (
            <Link to="/tools/jee-main-countdown" className={chip}>
              <span className="font-extrabold" suppressHydrationWarning>{jeeDays} days</span> to JEE Main 2027, Session 1
            </Link>
          )}
          {neetDays > 0 && (
            <Link to="/tools/neet-countdown" className={chip}>
              <span className="font-extrabold" suppressHydrationWarning>{neetDays} days</span> to 2 May 2027
              <span className="text-xs font-medium text-muted-foreground">NEET planning date, not official</span>
            </Link>
          )}
        </div>
        <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {TOOLS.map((t, i) => (
            <Rise key={t.to} delay={i * 0.05} className="min-w-0">
              <Link to={t.to} className="flex h-full flex-col rounded-3xl border border-border bg-card p-6 transition-colors hover:border-primary">
                <span className="text-2xl" aria-hidden>
                  {t.emoji}
                </span>
                <h3 className="font-display mt-3 text-lg font-extrabold text-foreground">{t.name}</h3>
                <p className="mt-1.5 text-sm leading-relaxed text-muted-foreground">{t.blurb}</p>
                <span className="mt-auto inline-flex items-center gap-1.5 pt-4 text-sm font-bold text-primary">
                  Open <ArrowRight className="h-4 w-4" />
                </span>
              </Link>
            </Rise>
          ))}
        </div>
        <p className="mt-6">
          <Link to="/tools" className="inline-flex min-h-11 items-center gap-1.5 text-sm font-bold text-primary">
            See all free tools <ArrowRight className="h-4 w-4" />
          </Link>
        </p>
      </div>
    </section>
  );
}

// ── What's new: the latest three releases, each linking to its own page ──
function WhatsNewSection() {
  return (
    <section id="whats-new" aria-labelledby="whats-new-heading" className="py-14 sm:py-20">
      <div className={WRAP}>
        <Rise className="flex flex-wrap items-end justify-between gap-4">
          <h2 id="whats-new-heading" className="font-display text-4xl leading-[1.05] tracking-tight text-foreground sm:text-5xl">
            <span className="block font-light">What's new</span>
            <span className="block font-extrabold">on Edurack.</span>
          </h2>
          <Link to="/whats-new" className="inline-flex min-h-11 items-center gap-1.5 text-sm font-bold text-primary">
            All updates <ArrowRight className="h-4 w-4" />
          </Link>
        </Rise>
        <div className="mt-8 grid gap-4 md:grid-cols-3">
          {RELEASES.slice(0, 3).map((r, i) => (
            <Rise key={r.slug} delay={i * 0.07} className="min-w-0">
              <Link to="/whats-new/$slug" params={{ slug: r.slug }} className="flex h-full flex-col rounded-3xl border border-border bg-card p-6 transition-colors hover:border-primary">
                <time dateTime={r.date} className="text-xs font-bold uppercase tracking-widest text-muted-foreground">
                  {formatReleaseDate(r.date)}
                </time>
                <h3 className="font-display mt-2 text-lg font-extrabold text-foreground">{r.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{r.summary}</p>
                <span className="mt-auto inline-flex items-center gap-1.5 pt-4 text-sm font-bold text-primary">
                  Read the details <ArrowRight className="h-4 w-4" />
                </span>
              </Link>
            </Rise>
          ))}
        </div>
      </div>
    </section>
  );
}

// ── Live exams + roadmap ───────────────────────────────────────────────────
const examCards: { key: "neet" | "jee"; full: string; blurb: string; links: { label: string; to: string }[] }[] = [
  { key: "neet", full: "NEET (UG)", blurb: "Previous year questions, chapter weightage and rank tools for medical aspirants.", links: [{ label: "Chapter weightage", to: "/neet/chapter-wise-weightage" }, { label: "Rank predictor", to: "/tools/neet-rank-predictor" }] },
  { key: "jee", full: "JEE Main & Advanced", blurb: "Chapter-wise practice with the JEE Main 2027 hub, weightage and paper analysis.", links: [{ label: "JEE Main 2027 hub", to: "/jee-main-2027" }, { label: "Chapter weightage", to: "/jee/chapter-wise-weightage" }] },
];

function ExamsSection() {
  return (
    <section id="exams" aria-labelledby="exams-heading" className="py-16 sm:py-24">
      <div className={WRAP}>
        <Rise className="max-w-2xl">
          <h2 id="exams-heading" className="font-display text-4xl leading-[1.05] tracking-tight text-foreground sm:text-5xl">
            <span className="block font-light">Your exam,</span>
            <span className="block font-extrabold">one platform.</span>
          </h2>
          <p className="mt-5 text-lg leading-relaxed text-muted-foreground">NEET and JEE are live. CUET and IPMAT are coming soon, with government and state entrance exams to follow.</p>
        </Rise>
        <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {examCards.map((c, i) => (
            <Rise key={c.key} delay={i * 0.07} className="min-w-0">
              <div className="flex h-full flex-col rounded-3xl border border-border bg-card p-6 transition-colors hover:border-primary">
                <h3 className="font-display text-2xl font-extrabold">{c.full}</h3>
                <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{c.blurb}</p>
                <Link to="/pyq" search={{ exam: c.key }} className="mt-5 inline-flex min-h-11 items-center gap-1.5 text-sm font-bold text-primary">
                  Practise {EXAM_DEMOS[c.key].label} <ArrowRight className="h-4 w-4" />
                </Link>
                <ul className="mt-auto flex flex-wrap gap-x-4 pt-2 text-sm">
                  {c.links.map((l) => (
                    <li key={l.label}><Link to={l.to} className="inline-flex min-h-9 items-center text-foreground/70 hover:text-foreground">{l.label}</Link></li>
                  ))}
                </ul>
              </div>
            </Rise>
          ))}
          <Rise delay={0.14} className="min-w-0">
            <div className="flex h-full flex-col rounded-3xl border border-dashed border-border p-6">
              <span className="w-fit rounded-full bg-primary/10 px-3 py-1 text-[11px] font-extrabold uppercase tracking-wide text-primary">Coming soon</span>
              <h3 className="mt-3 font-display text-2xl font-extrabold">CUET, IPMAT and more</h3>
              <p className="mt-3 text-sm leading-relaxed text-muted-foreground">CUET (UG) and IPMAT are next. We're expanding through 2027 into government and state entrance exams.</p>
              <Link to="/contact" className="mt-auto inline-flex min-h-11 items-center gap-1.5 pt-5 text-sm font-bold text-foreground">Tell us which exam you need <ArrowRight className="h-4 w-4" /></Link>
            </div>
          </Rise>
        </div>
      </div>
    </section>
  );
}

// ── Simulator + sample report ──────────────────────────────────────────────
function CbtSimulatorFallback() {
  return <div className="flex h-[420px] items-center justify-center rounded-2xl border border-border text-sm text-muted-foreground">Loading the CBT simulator…</div>;
}

function SimulatorSection() {
  const [exam, setExam] = usePreferredExam("simulator");
  const demo = EXAM_DEMOS[exam];
  const rows = demo.report.map((r) => ({ s: r.s, t: toneOf(r.v).word, c: toneOf(r.v).text, w: r.v }));
  return (
    <section id="simulator" className="py-20 sm:py-28">
      <div className={WRAP}>
        <Rise className="max-w-2xl">
          <Title light="Train for the screen" bold="you'll face on exam day." />
          <p className="mt-5 text-lg leading-relaxed text-muted-foreground">Question palette, section controls, flags and timers, laid out like the real paper. Try the interface right here.</p>
        </Rise>
        <Rise delay={0.1} className="mt-10">
          <div role="group" aria-label="Preview the simulator for your exam" className="mb-4 flex flex-wrap gap-2">
            {DEMO_EXAM_KEYS.map((k) => (
              <button key={k} type="button" onClick={() => setExam(k)} aria-pressed={exam === k} className={`min-h-11 rounded-full border px-4 text-sm font-bold transition-colors ${exam === k ? "border-primary bg-primary text-primary-foreground" : "border-border text-foreground/80 hover:border-foreground"}`}>{EXAM_DEMOS[k].label}</button>
            ))}
          </div>
          <Suspense fallback={<CbtSimulatorFallback />}><CbtSimulator exam={exam} /></Suspense>
        </Rise>

        <div className="mt-16 grid gap-10 lg:grid-cols-2 lg:items-center">
          <Rise>
            <h3 className="font-display text-3xl tracking-tight sm:text-4xl"><span className="font-light">Your mock doesn't end</span> <span className="font-extrabold">when you submit.</span></h3>
            <p className="mt-4 max-w-md text-muted-foreground">See where you lose marks and what to work on next, then get matched with someone who can help.</p>
            <div className="mt-7 flex flex-col gap-3 sm:flex-row">
              <Link to="/simulator/live" className={PREMIUM_BTN}>Try the CBT demo <ArrowRight className="h-4 w-4" /></Link>
              <a href="#mentors" className={GHOST_BTN}>Find a mentor</a>
            </div>
          </Rise>
          <Rise delay={0.1}>
            <div className="rounded-3xl border border-border bg-card p-6 sm:p-8">
              <p className="text-xs font-semibold text-muted-foreground">Sample performance report</p>
              <div className="mt-2 font-display text-5xl font-extrabold">{demo.score}<span className="text-xl font-medium text-muted-foreground"> / {demo.total}</span></div>
              <div className="mt-6 space-y-4">
                {rows.map((r, i) => (
                  <div key={r.s}>
                    <div className="mb-1.5 flex justify-between text-sm font-semibold"><span>{r.s}</span><span className={r.c}>{r.t}</span></div>
                    <div className="h-1.5 overflow-hidden rounded-full bg-secondary">
                      <motion.div className="h-full rounded-full bg-primary" initial={{ width: 0 }} whileInView={{ width: `${r.w}%` }} viewport={{ once: true }} transition={{ duration: 1, delay: 0.2 + i * 0.12, ease: EASE }} />
                    </div>
                  </div>
                ))}
              </div>
              <p className="mt-6 border-t border-border pt-4 text-sm text-muted-foreground">Focus next: {demo.focus.map((f, i) => <span key={f}>{i > 0 && ", "}<b className="text-foreground">{f}</b></span>)}</p>
            </div>
          </Rise>
        </div>
      </div>
    </section>
  );
}

// ── Mentors (real data, streamed) ──────────────────────────────────────────
type LandingMentor = {
  id: string; name: string; profilePictureUrl: string | null; yearOfStudy: string; aiimsIitRank: string; expertAt: string;
  batches: { id: string; name: string; track: string; exam: string }[];
};

function getInitials(name: string) {
  const p = name.trim().split(/\s+/).filter(Boolean);
  if (!p.length) return "?";
  return p.length === 1 ? p[0].slice(0, 2).toUpperCase() : (p[0][0] + p[p.length - 1][0]).toUpperCase();
}

function MentorAvatar({ src, name }: { src: string | null; name: string }) {
  if (!src) return <div role="img" aria-label={name} className="grid h-14 w-14 shrink-0 place-items-center rounded-full bg-primary/10 font-display text-sm font-bold text-primary">{getInitials(name)}</div>;
  return <img src={src} alt={name} width={56} height={56} loading="lazy" decoding="async" className="h-14 w-14 shrink-0 rounded-full object-cover" />;
}

function MentorShowcase() {
  const { mentorsPromise } = Route.useLoaderData();
  return (
    <section id="mentors" className="border-y border-border bg-secondary/50 py-20 sm:py-28">
      <div className={WRAP}>
        <Rise className="max-w-2xl">
          <Title light="Learn from someone" bold="who has done it." />
          <p className="mt-5 text-lg leading-relaxed text-muted-foreground">Mentors who cleared the exam you're preparing for. Pick one by goal, need and budget.</p>
        </Rise>
        <Suspense fallback={<p className="mt-10 text-muted-foreground">Loading the current mentor roster…</p>}>
          <Await promise={mentorsPromise}>{(mentors) => <MentorsResolved mentors={mentors} />}</Await>
        </Suspense>
      </div>
    </section>
  );
}

function MentorsResolved({ mentors }: { mentors: LandingMentor[] }) {
  if (!mentors.length) return <p className="mt-10 rounded-2xl border border-dashed border-border p-8 text-muted-foreground">Mentors are being onboarded right now. Check back shortly.</p>;
  return (
    <div className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
      {mentors.map((m, i) => (
        <Rise key={m.id} delay={(i % 3) * 0.08} className="min-w-0">
          <Link to="/mentor-profile/$mentorId" params={{ mentorId: m.id }} className="group flex h-full min-w-0 flex-col rounded-3xl border border-border bg-card p-5 transition-colors hover:border-primary">
            <div className="flex items-center gap-3">
              <MentorAvatar src={m.profilePictureUrl} name={m.name} />
              <div className="min-w-0">
                <h3 className="truncate font-display text-lg font-bold">{m.name}</h3>
                <p className="flex flex-wrap gap-x-3 text-xs font-medium text-muted-foreground">
                  {m.aiimsIitRank && <span className="inline-flex items-center gap-1"><Award className="h-3 w-3" />{m.aiimsIitRank}</span>}
                  {m.yearOfStudy && <span className="inline-flex items-center gap-1"><GraduationCap className="h-3 w-3" />{m.yearOfStudy}</span>}
                </p>
              </div>
            </div>
            {m.expertAt.length > 0 && (
              <p className="mt-4 break-words text-sm font-semibold text-primary [overflow-wrap:anywhere]">Expert in {m.expertAt}</p>
            )}
            {m.batches.length > 0 && (
              <ul className="mt-3 space-y-1.5 text-sm text-muted-foreground">
                {m.batches.map((b) => <li key={b.id} className="break-words [overflow-wrap:anywhere]">{b.name} · {b.exam.toUpperCase()} · {b.track}</li>)}
              </ul>
            )}
            <span className="mt-auto inline-flex items-center gap-1.5 pt-5 text-sm font-bold text-foreground">View profile <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" /></span>
          </Link>
        </Rise>
      ))}
    </div>
  );
}

// ── Features ───────────────────────────────────────────────────────────────
const featureList = [
  { icon: MonitorPlay, t: "Realistic exam practice", d: "An exam-like environment before the actual exam.", span: "lg:col-span-2" },
  { icon: LineChart, t: "Performance analytics", d: "Accuracy, speed and subject-wise gaps after every test.", span: "" },
  { icon: LayoutDashboard, t: "Progress tracking", d: "See your preparation across tests and topics.", span: "" },
  { icon: CalendarCheck, t: "Mentor marketplace", d: "Batches and sessions from mentors who cleared it, including free sessions.", span: "lg:col-span-2" },
];
const alsoOn = ["Lecture library", "Free mentor sessions", "Certificate verification", "Support tickets", "NEET · JEE"];

function FeaturesSection() {
  return (
    <section id="features" className="py-20 sm:py-28">
      <div className={WRAP}>
        <Rise className="max-w-2xl"><Title light="Everything to know" bold="where you stand." /></Rise>
        <div className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {featureList.map((f, i) => (
            <Rise key={f.t} delay={i * 0.07} className={f.span}>
              <div className="group h-full rounded-3xl border border-border p-6 transition-colors hover:bg-secondary/60 sm:p-8">
                <f.icon className="h-7 w-7 text-primary" stroke={1.6} />
                <h3 className="mt-10 font-display text-xl font-bold">{f.t}</h3>
                <p className="mt-2 max-w-sm text-muted-foreground">{f.d}</p>
              </div>
            </Rise>
          ))}
        </div>
        <Rise className="mt-8 flex flex-wrap gap-2">
          {alsoOn.map((a) => <span key={a} className="rounded-full border border-border px-4 py-2 text-sm font-semibold text-foreground/80">{a}</span>)}
        </Rise>
      </div>
    </section>
  );
}

// ── Blog (real data, streamed) ──────────────────────────────────────────────
// The homepage previously linked nowhere in the site to /blog or any post —
// no header link, no section, no footer link. Crawlers largely find pages
// by following links from already-indexed, frequently-crawled pages, and
// the homepage is that page here. Being in sitemap.xml alone doesn't carry
// the same weight, and gets crawled far less often. This section, plus the
// header/footer links added elsewhere in this file, give Google (and users)
// an actual path from "/" into the blog.
function BlogShowcase() {
  const { postsPromise } = Route.useLoaderData();
  return (
    <section id="blog" className="border-y border-border bg-secondary/50 py-20 sm:py-28">
      <div className={WRAP}>
        <Rise className="flex flex-wrap items-end justify-between gap-4">
          <div className="max-w-2xl">
            <Title light="Strategy and stories," bold="not just a product." />
            <p className="mt-5 text-lg leading-relaxed text-muted-foreground">Exam strategy, mentor stories and platform updates for NEET and JEE aspirants.</p>
          </div>
          <Link to="/blog" preload="viewport" className={`${GHOST_BTN} shrink-0`}>Read the blog <ArrowRight className="h-4 w-4" /></Link>
        </Rise>
        <Suspense fallback={<p className="mt-10 text-muted-foreground">Loading recent posts…</p>}>
          <Await promise={postsPromise}>{(posts) => <BlogPostsResolved posts={posts} />}</Await>
        </Suspense>
      </div>
    </section>
  );
}

function BlogPostsResolved({ posts }: { posts: PublicBlogPostSummary[] }) {
  if (!posts.length) return null;
  return (
    <div className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
      {posts.map((p, i) => (
        <Rise key={p.id} delay={(i % 3) * 0.08}>
          <Link to="/blog/$slug" params={{ slug: p.slug }} className="group flex h-full flex-col overflow-hidden rounded-3xl border border-border bg-card transition-colors hover:border-primary">
            {p.coverImageUrl && (
              <img src={p.coverImageUrl} alt={p.coverImageAlt} loading="lazy" decoding="async" className="h-40 w-full object-cover" />
            )}
            <div className="flex flex-1 flex-col p-5">
              <span className="text-xs font-semibold text-primary">{BLOG_CATEGORY_LABELS[p.category]}</span>
              <h3 className="mt-2 font-display text-lg font-bold leading-snug">{p.title}</h3>
              {p.excerpt && <p className="mt-2 line-clamp-2 text-sm text-muted-foreground">{p.excerpt}</p>}
              <span className="mt-auto inline-flex items-center gap-1.5 pt-5 text-sm font-bold text-foreground">Read more <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" /></span>
            </div>
          </Link>
        </Rise>
      ))}
    </div>
  );
}

// ── Mentor banner, careers, final CTA ──────────────────────────────────────
function MentorBanner() {
  return (
    <section id="marketplace" className={`${INK} py-20 sm:py-28`}>
      <div className={`${WRAP} grid gap-10 lg:grid-cols-2 lg:items-center`}>
        <Rise>
          <p className="inline-flex items-center gap-2 rounded-full border border-white/15 px-3.5 py-1.5 text-sm font-semibold text-[#7ba4f0]"><UserCheck className="h-4 w-4" /> Founding 25 mentors</p>
          <h2 className="mt-5 font-display text-4xl leading-[1.05] tracking-tight sm:text-5xl"><span className="block font-light">You cleared the exam.</span><span className="block font-extrabold">Help someone clear it.</span></h2>
          <p className="mt-5 max-w-md text-white/60">Create your own batch, set your price and teach your way. Edurack handles the platform, enrolment and payments.</p>
          <Link to="/join-mentor" preload="viewport" className="mt-8 inline-flex min-h-12 items-center gap-2 rounded-full bg-[#ffffff] px-6 text-[15px] font-bold text-[#141b2b] transition-transform active:scale-[.97] hover:-translate-y-0.5">Become a founding mentor <ArrowRight className="h-4 w-4" /></Link>
        </Rise>
        <Rise delay={0.1} className="grid grid-cols-2 gap-px overflow-hidden rounded-3xl border border-white/15 bg-white/15">
          {[["Your batch", "You decide"], ["Your price", "You decide"], ["Enrolment and payments", "Edurack handles"], ["Discovery and promotion", "Edurack handles"]].map(([a, b]) => (
            <div key={a} className="bg-[#141b2b] p-5"><p className="font-display font-bold">{a}</p><p className="mt-1 text-sm text-white/50">{b}</p></div>
          ))}
        </Rise>
      </div>
    </section>
  );
}

function CareersStrip() {
  return (
    <section id="careers" className={WRAP + " py-16"}>
      <Rise className="flex flex-col gap-5 rounded-3xl border border-border p-6 sm:flex-row sm:items-center sm:justify-between sm:p-8">
        <div>
          <p className="flex items-center gap-2 text-sm font-semibold text-primary"><Briefcase className="h-4 w-4" /> Careers</p>
          <h3 className="mt-1 font-display text-2xl font-extrabold">Build the question bank behind Edurack.</h3>
          <p className="mt-1 text-muted-foreground">Remote, flexible hours, offer letter and certificate. Takes two minutes to apply.</p>
        </div>
        <Link to="/join-intern" preload="viewport" className={`${GHOST_BTN} shrink-0`}>Apply to intern <ArrowRight className="h-4 w-4" /></Link>
      </Rise>
    </section>
  );
}

function FinalCta() {
  const { user } = useAuth();
  return (
    <section className="py-20 sm:py-28">
      <Rise className={`${WRAP} text-center`}>
        <h2 className="font-display text-5xl leading-[1.02] tracking-tight sm:text-7xl"><span className="block font-light">Stop guessing.</span><span className="block font-extrabold">Start fixing.</span></h2>
        <p className="mx-auto mt-5 max-w-md text-lg text-muted-foreground">Practise free, then see exactly where your marks go, whichever exam you're preparing for.</p>
        <div className="mx-auto mt-8 flex max-w-md flex-col gap-3 sm:flex-row sm:justify-center">
          {user ? (
            <>
              <Link to="/dashboard" className={PREMIUM_BTN}>Go to your dashboard <ArrowRight className="h-4 w-4" /></Link>
              <Link to="/simulator/live" className={GHOST_BTN}>Try the CBT demo</Link>
            </>
          ) : (
            <>
              <Link to="/simulator/live" className={PREMIUM_BTN}>Try the CBT demo <ArrowRight className="h-4 w-4" /></Link>
              <Link to="/auth" search={{ tab: "signup" }} className={GHOST_BTN}>Create free account</Link>
            </>
          )}
        </div>
      </Rise>
    </section>
  );
}

// ── Footer ─────────────────────────────────────────────────────────────────
type FooterLink = { label: string; to: string };
const footerColumns: { title: string; links: FooterLink[] }[] = [
  { title: "Product", links: [{ label: "About us", to: "/about" }, { label: "CBT Simulator", to: "/simulator/live" }, { label: "Dashboard", to: "/dashboard" }, { label: "Mentorship sessions", to: "/mentorship-sessions" }, { label: "Edurack Pro", to: "/pro" }, { label: "Become a mentor", to: "/join-mentor" }, { label: "Internships", to: "/join-intern" }, { label: "Blog", to: "/blog" }, { label: "Free resources", to: "/free-resources" }] },
  { title: "NEET guides", links: [{ label: "Chapter-wise weightage", to: "/neet/chapter-wise-weightage" }, { label: "Physics weightage", to: "/neet/chapter-wise-weightage/physics" }, { label: "Chemistry weightage", to: "/neet/chapter-wise-weightage/chemistry" }, { label: "Botany weightage", to: "/neet/chapter-wise-weightage/botany" }, { label: "Zoology weightage", to: "/neet/chapter-wise-weightage/zoology" }, { label: "PYQ practice", to: "/pyq" }] },
  { title: "JEE guides", links: [{ label: "JEE Main 2027 hub", to: "/jee-main-2027" }, { label: "Chapter-wise weightage", to: "/jee/chapter-wise-weightage" }, { label: "Physics weightage", to: "/jee/chapter-wise-weightage/physics" }, { label: "Chemistry weightage", to: "/jee/chapter-wise-weightage/chemistry" }, { label: "Maths weightage", to: "/jee/chapter-wise-weightage/maths" }, { label: "JEE syllabus 2026", to: "/jee/syllabus" }, { label: "Paper analysis", to: "/jee/paper-analysis" }, { label: "High-weightage chapters", to: "/jee/high-weightage-chapters" }, { label: "Most repeated concepts", to: "/jee/most-repeated-concepts" }, { label: "PYQ practice", to: "/pyq" }] },
  { title: "Help", links: [{ label: "FAQ", to: "/faq" }, { label: "Help centre", to: "/help" }, { label: "Contact us", to: "/contact" }, { label: "Verify certificate", to: "/verify" }] },
  { title: "Legal", links: [{ label: "Terms", to: "/legal/terms" }, { label: "Privacy", to: "/legal/privacy" }, { label: "Refund", to: "/legal/refund" }] },
];

function Footer() {
  return (
    <footer className={`${INK} pb-10 pt-16`}>
      <div className={WRAP}>
        <div className="grid gap-10 md:grid-cols-[1.4fr_1fr_1fr_1fr_1fr_1fr]">
          <div>
            <Link to="/" className="flex items-center gap-2"><img src="/edurack-logo.webp" alt="EDURACK" width={160} height={160} className="h-10 w-auto object-contain" /><span className="font-display text-xl font-extrabold">edurack</span></Link>
            <p className="mt-4 max-w-xs text-sm leading-relaxed text-white/60"><strong className="text-white">edurack.in</strong> is an independent platform for exam-format CBT practice and mentorship for NEET and JEE aspirants.</p>
            <p className="mt-2 max-w-xs text-sm text-white/40">Founded by Vishal Sharma, Tarun Yadav and Archita Priyadarshinee. {LAUNCH_DATE_LABEL}.</p>
            <div className="mt-5 flex gap-2">
              {socialLinks.map((s) => (
                <a key={s.name} href={s.href} target="_blank" rel="noopener noreferrer" aria-label={s.name} className="grid h-11 w-11 place-items-center rounded-full border border-white/15 text-white/70 transition-colors hover:border-white/40 hover:text-white"><s.icon className="h-[18px] w-[18px]" /></a>
              ))}
            </div>
          </div>
          {footerColumns.map((c) => (
            <div key={c.title}>
              <p className="font-display text-sm font-bold">{c.title}</p>
              <ul className="mt-3 space-y-1">{c.links.map((l) => <li key={l.label}><Link to={l.to} className="inline-flex min-h-9 items-center text-sm text-white/60 transition-colors hover:text-white">{l.label}</Link></li>)}</ul>
            </div>
          ))}
        </div>
        <p className="mt-12 border-t border-white/10 pt-6 text-xs text-white/40">© {new Date().getFullYear()} EDURACK (edurack.in). All rights reserved.</p>
      </div>
    </footer>
  );
}