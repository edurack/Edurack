// Shown once per login session when the student hasn't practised today (no streak progress yet).
// It carries today's daily PYQ so they can answer right there, which counts toward the streak
// through the same submitPyqAnswer call the PYQ page uses.
import { useEffect, useRef, useState } from "react";
import { Link } from "@tanstack/react-router";
import { Flame, Check, X as XIcon, ArrowRight } from "lucide-react";
import { IconLoader2 as Loader2 } from "@tabler/icons-react";
import { Dialog, DialogContent, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { useAuth } from "@/lib/auth-context";
import { SmartContent } from "@/lib/smart-content";
import { getTodaySummary, listPyqSession } from "@/server-functions/practice-extras";
import { submitPyqAnswer } from "@/server-functions/pyq-practice";
import type { OptionKey, PyqCheckResult, PyqQuestion, TodaySummary } from "@/lib/pyq-types";
import { cn } from "@/lib/utils";
import { track, trackOnce } from "@/lib/analytics";
import { answeredProps, practiceProps } from "@/lib/practice-events";
import { examLabel } from "@/lib/practice-stats";

const OPTS: OptionKey[] = ["A", "B", "C", "D"];
/** Fired after an answer is saved from the popup, so PyqHero can refetch and light the flame. */
export const PRACTICE_ANSWERED_EVENT = "edurack:practice-answered";
const dayKey = () => new Date().toLocaleDateString("en-CA", { timeZone: "Asia/Kolkata" });

function seenKey(uid: string) {
  return `edurack-streak-popup:${uid}:${dayKey()}`;
}
// What the student had picked/typed, kept for the day so closing the popup (or a refresh) doesn't lose it.
const draftKey = (uid: string, qid: string) => `edurack-daily-draft:${uid}:${dayKey()}:${qid}`;
// Set the moment today's answer is saved: the popup never comes back for a question already answered today.
const doneKey = (uid: string) => `edurack-daily-done:${uid}:${dayKey()}`;
const isDoneToday = (uid: string) => { try { return localStorage.getItem(doneKey(uid)) === "1"; } catch { return false; } };
function markSeen(uid: string) {
  try { sessionStorage.setItem(seenKey(uid), "1"); } catch { /* storage unavailable: popup may show again, harmless */ }
}
function wasSeen(uid: string) {
  try { return sessionStorage.getItem(seenKey(uid)) === "1"; } catch { return false; }
}

export function StreakPopup() {
  const { user } = useAuth();
  const [open, setOpen] = useState(false);
  const [today, setToday] = useState<TodaySummary | null>(null);
  const [q, setQ] = useState<PyqQuestion | null>(null);
  const [pick, setPick] = useState<OptionKey | null>(null);
  const [num, setNum] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [result, setResult] = useState<PyqCheckResult | null>(null);

  useEffect(() => {
    if (!user || wasSeen(user.uid) || isDoneToday(user.uid)) return;
    let cancelled = false;
    (async () => {
      try {
        const token = await user.getIdToken();
        const t = await getTodaySummary({ data: { token } });
        if (cancelled || t.streak.doneToday || !t.daily.available || t.daily.done) return;
        const list = await listPyqSession({ data: { token, kind: "daily" } });
        const first = list.questions[0];
        if (cancelled || !first) return;
        setToday(t);
        setQ(first);
        try {
          const raw = localStorage.getItem(draftKey(user.uid, first.id));
          if (raw) {
            const d = JSON.parse(raw) as { pick?: OptionKey; num?: string };
            if (d.pick && OPTS.includes(d.pick)) setPick(d.pick);
            if (typeof d.num === "string") setNum(d.num.slice(0, 20));
          }
        } catch { /* a missing or corrupt draft just means starting empty */ }
        setOpen(true);
        markSeen(user.uid); // once per login session: refreshing or navigating back won't nag again
      } catch {
        /* the popup is a nudge, never an error */
      }
    })();
    return () => { cancelled = true; };
  }, [user]);

  // Save the draft as the student picks, so dismissing the popup doesn't lose their choice.
  useEffect(() => {
    if (!user || !q || result) return;
    try {
      if (pick || num) localStorage.setItem(draftKey(user.uid, q.id), JSON.stringify({ pick, num }));
    } catch { /* storage unavailable: nothing to restore later, harmless */ }
  }, [user, q, pick, num, result]);

  // Two quick taps must send ONE answer: state updates are async, so a ref closes the gap `busy` leaves.
  const inflight = useRef(false);
  async function submit() {
    if (!user || !q || result || inflight.current) return;
    inflight.current = true;
    setBusy(true);
    setErr(null);
    try {
      const token = await user.getIdToken();
      const answer = q.type === "mcq" ? { option: pick ?? undefined } : { value: Number(num) };
      const out = await submitPyqAnswer({ data: { token, questionId: q.id, answer } });
      setResult(out);
      try {
        localStorage.setItem(doneKey(user.uid), "1");
        localStorage.removeItem(draftKey(user.uid, q.id));
      } catch { /* the server also knows it's answered, so the popup still won't repeat */ }
      // This answer bypasses the PYQ practice screen, so it is tracked here: it's an answered question AND today's daily question.
      const ctx = { mode: "daily" as const, exam: today?.exam, subject: q.subject, chapter: q.chapter, source: "daily_popup" };
      track("question_answered", answeredProps(ctx, { questionId: q.id, questionType: q.type, isCorrect: out.isCorrect }));
      trackOnce(`daily:${user.uid}`, "daily_question_completed", { ...practiceProps(ctx), is_correct: out.isCorrect }, "day");
      // The dashboard hero (flame, week strip, progress ring) lives outside this dialog: tell it to refresh.
      window.dispatchEvent(new Event(PRACTICE_ANSWERED_EVENT));
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Couldn't check that. Try again.");
    } finally {
      inflight.current = false;
      setBusy(false);
    }
  }

  if (!q) return null;
  const atRisk = (today?.streak.current ?? 0) > 0;
  const canSubmit = q.type === "mcq" ? pick !== null : num.trim() !== "" && Number.isFinite(Number(num));
  const newStreak = result?.streak?.current;

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogContent className="max-h-[92vh] w-[calc(100vw-1.5rem)] max-w-lg gap-0 overflow-y-auto rounded-3xl border-0 p-0 [&>button]:text-white">
        <div className="ink-section relative isolate overflow-hidden px-5 pb-5 pt-6 sm:px-6">
          <div aria-hidden className="pointer-events-none absolute -right-16 -top-20 -z-10 h-52 w-52 rounded-full bg-amber-300/20 blur-3xl" />
          {result ? (
            <div className="animate-in fade-in zoom-in-95 duration-300">
              <div className="flex items-center gap-3">
                <span className={cn("grid h-12 w-12 place-items-center rounded-2xl", result.isCorrect ? "bg-emerald-400 text-emerald-950" : "bg-amber-300 text-amber-950")}>
                  {result.isCorrect ? <Check className="h-6 w-6" strokeWidth={3} /> : <XIcon className="h-6 w-6" strokeWidth={3} />}
                </span>
                <div>
                  <DialogTitle className="font-display text-xl font-extrabold text-white">{result.isCorrect ? "Correct!" : "Not quite, and that's fine"}</DialogTitle>
                  <DialogDescription className="text-sm text-white/65">
                    {newStreak ? `🔥 ${newStreak}-day streak${result.streak?.increased ? " and growing" : ""}` : "Your streak is safe for today."}
                  </DialogDescription>
                </div>
              </div>
            </div>
          ) : (
            <>
              <div className="flex items-center gap-2">
                <span className="grid h-9 w-9 place-items-center rounded-xl bg-amber-300 text-amber-950"><Flame className="h-5 w-5 fill-current" aria-hidden /></span>
                <p className="text-[11px] font-extrabold uppercase tracking-widest text-amber-200">{atRisk ? `Keep your ${today!.streak.current}-day streak` : "Start your streak"}</p>
              </div>
              <DialogTitle className="font-display mt-3 text-2xl font-extrabold leading-tight text-white">
                Today's {examLabel(today?.exam)} Challenge
              </DialogTitle>
              <DialogDescription className="mt-1 text-sm text-white/65">One question today. One step closer to your goal.</DialogDescription>
            </>
          )}
        </div>

        <div className="space-y-4 bg-card px-5 pb-5 pt-4 text-foreground sm:px-6">
          <div className="flex flex-wrap gap-1.5 text-[11px] font-bold text-muted-foreground">
            <span className="rounded-full bg-secondary px-2.5 py-1">{q.subject}</span>
            {q.chapter && <span className="rounded-full bg-secondary px-2.5 py-1">{q.chapter}</span>}
            {q.source?.year && <span className="rounded-full bg-secondary px-2.5 py-1">{q.source.year}</span>}
          </div>
          <SmartContent value={q.body} className="text-[15px] leading-relaxed" />

          {q.type === "mcq" && q.options ? (
            <ul className="space-y-2">
              {OPTS.filter((k) => q.options?.[k]).map((k) => {
                const isPick = pick === k;
                const isRight = result && result.correctOption === k;
                const isWrongPick = result && isPick && !result.isCorrect;
                return (
                  <li key={k}>
                    <button
                      type="button" disabled={!!result || busy} onClick={() => setPick(k)}
                      className={cn(
                        "flex min-h-12 w-full items-start gap-3 rounded-2xl border px-3 py-2.5 text-left text-sm transition-colors",
                        isRight ? "border-emerald-500 bg-emerald-500/10" : isWrongPick ? "border-rose-500 bg-rose-500/10" : isPick ? "border-primary bg-primary/10" : "border-border hover:border-foreground/40",
                      )}
                    >
                      <span className={cn("grid h-6 w-6 shrink-0 place-items-center rounded-full text-xs font-extrabold", isPick || isRight ? "bg-primary text-primary-foreground" : "bg-secondary")}>{k}</span>
                      <SmartContent value={q.options?.[k] ?? ""} className="min-w-0 flex-1" />
                    </button>
                  </li>
                );
              })}
            </ul>
          ) : (
            <input
              inputMode="decimal" value={num} onChange={(e) => setNum(e.target.value)} disabled={!!result || busy} placeholder="Type your numeric answer"
              className="min-h-12 w-full rounded-2xl border border-border bg-background px-4 text-sm focus:border-primary focus:outline-none"
            />
          )}

          {err && <p className="text-xs font-semibold text-rose-600">{err}</p>}

          {result ? (
            <div className="space-y-3 animate-in fade-in duration-300">
              {result.solution && (
                <div className="rounded-2xl bg-secondary p-4">
                  <p className="mb-1 text-[11px] font-extrabold uppercase tracking-wide text-muted-foreground">Solution</p>
                  <SmartContent value={result.solution} className="text-sm leading-relaxed" />
                </div>
              )}
              <div className="flex flex-col gap-2 sm:flex-row">
                <Link to="/pyq" search={{ subject: q.subject, chapter: q.chapter, practice: true, first5: true, exam: today?.exam ?? undefined }} onClick={() => { track("daily_more_practice_clicked", { source: "daily_modal" }); setOpen(false); }} className="clay-btn inline-flex min-h-11 flex-1 items-center justify-center gap-2 px-5 text-sm">
                  Practise 5 More Questions <ArrowRight className="h-4 w-4" />
                </Link>
                <button type="button" onClick={() => setOpen(false)} className="min-h-11 rounded-full px-5 text-sm font-bold text-muted-foreground hover:bg-secondary">Done for now</button>
              </div>
            </div>
          ) : (
            <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
              <button type="button" onClick={submit} disabled={!canSubmit || busy} className="clay-btn inline-flex min-h-12 flex-1 items-center justify-center gap-2 px-5 text-sm disabled:opacity-50">
                {busy && <Loader2 className="h-4 w-4 animate-spin" />} Check my answer
              </button>
              <button type="button" onClick={() => setOpen(false)} className="min-h-11 rounded-full px-5 text-sm font-semibold text-muted-foreground hover:bg-secondary">Maybe later</button>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
