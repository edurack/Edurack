import { useEffect, useRef, useState, type FormEvent } from "react";
import { IconLoader2 as Loader2, IconMessageCircle as MessageSquare, IconSend as Send, IconLock as Lock, IconShieldCheck as ShieldCheck, IconFileText as FileText, IconClock as Clock, IconPlus as Plus, IconX as X, IconArrowLeft as ArrowLeft, IconPlayerPlayFilled as PlayCircle, IconStack2 as Layers3 } from "@tabler/icons-react";
import { Unlock, FileUp } from "lucide-react"; // TODO: no Tabler mapping found yet
import {
  listMyAssignedBatches,
  listChatThreads,
  listChatMessages,
  sendChatMessage,
  getChatLockWindow,
  setChatLockWindow,
  uploadMentorNote,
  listMentorNotes,
  listBatchStudents,
  listBatchLecturesForNoteScope,
} from "@/server-functions/mentor-portal";
import {
  ModuleHeader,
  ClayField,
  Panel,
  LoadingBlock,
  EmptyState,
  ErrorBanner,
  FileUploadField,
  inputClass,
  textareaClass,
} from "@/components/mentor-portal-ui";
import { useTour, OnboardingTour, type TourStep } from "@/components/shared/onboarding-tour";

type Batch = { id: string; name: string; track: string };
type Thread = {
  studentUid: string;
  studentName: string;
  lastMessage: string;
  lastMessageAt: string | null;
  lastSender: "mentor" | "student";
};
type ChatMessage = { id: string; sender: "mentor" | "student"; body: string; createdAt: string | null };
type Student = { uid: string; fullName: string; email: string | null };
type LectureOption = { id: string; lectureTitle: string };
type Note = { id: string; fileName: string; fileUrl: string; lectureSessionId: string | null; createdAt: string | null };

const CHAT_TOUR_STEPS: TourStep[] = [
  {
    selector: '[data-tour="chat-canvas"]',
    title: "Split-pane chat",
    description: "Every student thread on the left, the conversation on the right. Use \"New message\" to start a DM with anyone in the batch.",
  },
  {
    selector: '[data-tour="chat-lock"]',
    title: "Daily messaging window",
    description: "Lock chat to a specific window each day if you don't want students messaging around the clock.",
  },
  {
    selector: '[data-tour="chat-notes"]',
    title: "Notes",
    description: "Upload a file scoped to the whole batch or to a single lecture — students see it attached to the right place.",
  },
];

export function MentorChatModule({ mentorToken }: { mentorToken: string }) {
  const [batches, setBatches] = useState<Batch[] | null>(null);
  const [batchId, setBatchId] = useState("");
  const tour = useTour("mentorTourChatSeen");

  useEffect(() => {
    (async () => {
      const { batches: rows } = await listMyAssignedBatches({ data: { token: mentorToken } });
      setBatches(rows);
      if (rows.length > 0) setBatchId(rows[0].id);
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mentorToken]);

  return (
    <div>
      <ModuleHeader
        title="Student Chat Desk"
        subtitle="Split-pane DM canvas with a lockable daily messaging window, plus notes you can attach to the whole batch or a single lecture."
        onHelp={tour.start}
      />

      {batches === null ? (
        <LoadingBlock />
      ) : batches.length === 0 ? (
        <EmptyState icon={MessageSquare} message="No mentorship batches are assigned to you yet." />
      ) : (
        <>
          <div className="mb-6">
            <ClayField label="Batch">
              <select value={batchId} onChange={(e) => setBatchId(e.target.value)} className={inputClass + " appearance-none"}>
                {batches.map((b) => (
                  <option key={b.id} value={b.id}>
                    {b.name} · {b.track}
                  </option>
                ))}
              </select>
            </ClayField>
          </div>

          {batchId && (
            <div className="space-y-6">
              <div data-tour="chat-canvas">
                <ChatCanvas mentorToken={mentorToken} batchId={batchId} />
              </div>
              <div data-tour="chat-lock">
                <ChatLockControl mentorToken={mentorToken} batchId={batchId} />
              </div>
              <div data-tour="chat-notes">
                <NoteUploadGate mentorToken={mentorToken} batchId={batchId} />
              </div>
            </div>
          )}
        </>
      )}

      {tour.active && <OnboardingTour steps={CHAT_TOUR_STEPS} onFinish={tour.finish} />}
    </div>
  );
}

// ─── Split-pane chat canvas ────────────────────────────────────────────────
function ChatCanvas({ mentorToken, batchId }: { mentorToken: string; batchId: string }) {
  const [threads, setThreads] = useState<Thread[] | null>(null);
  const [activeStudentUid, setActiveStudentUid] = useState<string | null>(null);
  const [messages, setMessages] = useState<ChatMessage[] | null>(null);
  const [draft, setDraft] = useState("");
  const [sending, setSending] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showNewMessage, setShowNewMessage] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  async function refreshThreads() {
    const { threads: rows } = await listChatThreads({ data: { token: mentorToken, batchId } });
    setThreads(rows);
  }

  async function refreshMessages(studentUid: string) {
    const { messages: rows } = await listChatMessages({ data: { token: mentorToken, batchId, studentUid } });
    setMessages(rows);
  }

  useEffect(() => {
    setActiveStudentUid(null);
    setMessages(null);
    refreshThreads();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [batchId]);

  useEffect(() => {
    if (activeStudentUid) refreshMessages(activeStudentUid);
    else setMessages(null);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeStudentUid]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  async function handleSend(e: FormEvent) {
    e.preventDefault();
    setError(null);
    if (!draft.trim() || !activeStudentUid) return;

    setSending(true);
    try {
      await sendChatMessage({ data: { token: mentorToken, batchId, studentUid: activeStudentUid, body: draft } });
      setDraft("");
      await refreshMessages(activeStudentUid);
      await refreshThreads();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not send. Try again.");
    } finally {
      setSending(false);
    }
  }

  function handleThreadStarted(studentUid: string) {
    setShowNewMessage(false);
    refreshThreads();
    setActiveStudentUid(studentUid);
  }

  const activeThread = threads?.find((t) => t.studentUid === activeStudentUid);
  const hasActive = Boolean(activeStudentUid);

  return (
    <div className="clay grid grid-cols-1 overflow-hidden sm:grid-cols-[220px_1fr]">
      {/* ── Thread list — hidden on mobile once a thread is open ────── */}
      <div className={`border-foreground/10 sm:block sm:border-b-0 sm:border-r ${hasActive ? "hidden" : "block"}`}>
        <div className="flex items-center justify-between gap-2 px-4 py-3.5">
          <div className="flex items-center gap-2">
            <MessageSquare className="h-4 w-4 text-foreground/60" />
            <span className="text-xs font-semibold uppercase tracking-wide text-foreground/60">Threads</span>
          </div>
          <button
            onClick={() => setShowNewMessage(true)}
            className="flex h-7 w-7 items-center justify-center rounded-full text-foreground/50 hover:bg-foreground/5 hover:text-foreground"
            aria-label="Start a new conversation"
          >
            <Plus className="h-4 w-4" />
          </button>
        </div>
        {threads === null ? (
          <LoadingBlock compact />
        ) : threads.length === 0 ? (
          <div className="px-4 pb-4">
            <p className="mb-2 text-xs text-foreground/50">No conversations yet.</p>
            <button
              onClick={() => setShowNewMessage(true)}
              className="inline-flex items-center gap-1.5 text-xs font-semibold text-[var(--sky-deep)] hover:underline"
            >
              <Plus className="h-3 w-3" /> Start a conversation
            </button>
          </div>
        ) : (
          <ul className="max-h-80 overflow-y-auto pb-2 sm:max-h-[26rem]">
            {threads.map((t) => (
              <li key={t.studentUid}>
                <button
                  onClick={() => setActiveStudentUid(t.studentUid)}
                  className={`w-full px-4 py-2.5 text-left transition-colors ${
                    activeStudentUid === t.studentUid ? "bg-[var(--sky-soft)]/50" : "hover:bg-foreground/5"
                  }`}
                >
                  <p className="truncate text-sm font-semibold text-foreground">{t.studentName}</p>
                  <p className="truncate text-xs text-foreground/50">
                    {t.lastSender === "mentor" ? "You: " : ""}
                    {t.lastMessage}
                  </p>
                </button>
              </li>
            ))}
          </ul>
        )}
      </div>

      {/* ── DM interface — hidden on mobile until a thread is chosen ──── */}
      <div className={`min-h-[24rem] flex-col sm:flex ${hasActive ? "flex" : "hidden"}`}>
        <div className="flex items-center gap-2 border-b border-foreground/10 px-4 py-3.5">
          <button
            onClick={() => setActiveStudentUid(null)}
            className="text-foreground/40 hover:text-foreground/70 sm:hidden"
            aria-label="Back to threads"
          >
            <ArrowLeft className="h-4 w-4" />
          </button>
          <p className="truncate text-sm font-semibold text-foreground">
            {activeThread?.studentName ?? "Select a thread, or start a new one"}
          </p>
        </div>

        <div className="flex-1 space-y-2 overflow-y-auto p-4">
          {!activeStudentUid ? (
            <div className="flex h-full flex-col items-center justify-center gap-2 text-center text-foreground/40">
              <MessageSquare className="h-8 w-8" strokeWidth={1.5} />
              <p className="text-xs">Pick a conversation on the left, or tap + to message a student.</p>
            </div>
          ) : messages === null ? (
            <LoadingBlock compact />
          ) : messages.length === 0 ? (
            <p className="text-xs text-foreground/50">No messages yet — say hello.</p>
          ) : (
            messages.map((m) => (
              <div key={m.id} className={`flex ${m.sender === "mentor" ? "justify-end" : "justify-start"}`}>
                <div className={`max-w-[75%] rounded-2xl px-3.5 py-2 text-sm ${m.sender === "mentor" ? "clay-btn text-white" : "clay-inset text-foreground"}`}>
                  {m.body}
                </div>
              </div>
            ))
          )}
          <div ref={bottomRef} />
        </div>

        {activeStudentUid && (
          <form onSubmit={handleSend} className="border-t border-foreground/10 p-3">
            {error && (
              <div className="mb-2">
                <ErrorBanner message={error} />
              </div>
            )}
            <div className="flex items-center gap-2">
              <input
                value={draft}
                onChange={(e) => setDraft(e.target.value)}
                placeholder="Type a message…"
                className={inputClass + " flex-1"}
              />
              <button
                type="submit"
                disabled={sending || !draft.trim()}
                className="clay-btn flex h-10 w-10 shrink-0 items-center justify-center rounded-full disabled:opacity-70"
                aria-label="Send"
              >
                {sending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
              </button>
            </div>
          </form>
        )}
      </div>

      {showNewMessage && (
        <NewMessageModal
          mentorToken={mentorToken}
          batchId={batchId}
          existingThreadUids={(threads ?? []).map((t) => t.studentUid)}
          onClose={() => setShowNewMessage(false)}
          onSent={handleThreadStarted}
        />
      )}
    </div>
  );
}

function NewMessageModal({
  mentorToken,
  batchId,
  existingThreadUids,
  onClose,
  onSent,
}: {
  mentorToken: string;
  batchId: string;
  existingThreadUids: string[];
  onClose: () => void;
  onSent: (studentUid: string) => void;
}) {
  const [students, setStudents] = useState<Student[] | null>(null);
  const [studentUid, setStudentUid] = useState("");
  const [message, setMessage] = useState("");
  const [sending, setSending] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    (async () => {
      const { students: rows } = await listBatchStudents({ data: { token: mentorToken, batchId } });
      setStudents(rows);
      if (rows.length > 0) setStudentUid(rows[0].uid);
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [batchId]);

  async function handleSend(e: FormEvent) {
    e.preventDefault();
    setError(null);
    if (!studentUid) return setError("Select a student.");
    if (!message.trim()) return setError("Write a message first.");

    setSending(true);
    try {
      await sendChatMessage({ data: { token: mentorToken, batchId, studentUid, body: message } });
      onSent(studentUid);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not send. Try again.");
    } finally {
      setSending(false);
    }
  }

  return (
    <div className="fixed inset-0 z-30 flex items-center justify-center bg-black/30 px-4" onClick={onClose}>
      <div className="clay w-full max-w-md p-5 sm:p-6" onClick={(e) => e.stopPropagation()}>
        <div className="mb-4 flex items-center justify-between">
          <h3 className="text-sm font-semibold uppercase tracking-[0.15em] text-foreground/60">New message</h3>
          <button onClick={onClose} className="text-foreground/40 hover:text-foreground/70">
            <X className="h-4 w-4" />
          </button>
        </div>

        {students === null ? (
          <LoadingBlock compact />
        ) : students.length === 0 ? (
          <EmptyState message="No students have purchased this batch yet." />
        ) : (
          <form onSubmit={handleSend} className="space-y-4">
            <ClayField label="Student">
              <select value={studentUid} onChange={(e) => setStudentUid(e.target.value)} className={inputClass + " appearance-none"}>
                {students.map((s) => (
                  <option key={s.uid} value={s.uid}>
                    {s.fullName}
                    {existingThreadUids.includes(s.uid) ? " (existing thread)" : ""}
                  </option>
                ))}
              </select>
            </ClayField>

            <ClayField label="Message">
              <textarea
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                rows={4}
                placeholder="Type your first message…"
                className={textareaClass}
              />
            </ClayField>

            {error && <ErrorBanner message={error} />}

            <button
              type="submit"
              disabled={sending}
              className="clay-btn flex w-full items-center justify-center gap-2 rounded-full px-6 py-2.5 text-sm font-semibold disabled:opacity-70"
            >
              {sending ? <Loader2 className="h-4 w-4 animate-spin" /> : "Send message"}
            </button>
          </form>
        )}
      </div>
    </div>
  );
}

// ─── Interval lock/unlock control ──────────────────────────────────────────
function ChatLockControl({ mentorToken, batchId }: { mentorToken: string; batchId: string }) {
  const [enabled, setEnabled] = useState(false);
  const [openFrom, setOpenFrom] = useState("09:00");
  const [openUntil, setOpenUntil] = useState("18:00");
  const [isLockedNow, setIsLockedNow] = useState(false);
  const [saving, setSaving] = useState(false);

  async function refresh() {
    const { window: w, isLockedNow: locked } = await getChatLockWindow({ data: { token: mentorToken, batchId } });
    setEnabled(Boolean(w));
    if (w) {
      setOpenFrom(w.openFrom);
      setOpenUntil(w.openUntil);
    }
    setIsLockedNow(locked);
  }

  useEffect(() => {
    refresh();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [batchId]);

  async function toggle() {
    setSaving(true);
    try {
      await setChatLockWindow({ data: { token: mentorToken, batchId, enabled: !enabled, openFrom, openUntil } });
      await refresh();
    } finally {
      setSaving(false);
    }
  }

  async function saveWindow() {
    setSaving(true);
    try {
      await setChatLockWindow({ data: { token: mentorToken, batchId, enabled: true, openFrom, openUntil } });
      await refresh();
    } finally {
      setSaving(false);
    }
  }

  return (
    <Panel
      icon={Clock}
      title="Daily messaging window"
      action={
        <button
          type="button"
          onClick={toggle}
          disabled={saving}
          className={`inline-flex items-center gap-2 rounded-full px-4 py-2 text-xs font-semibold transition-all disabled:opacity-70 ${
            enabled ? "clay-btn text-white" : "clay-btn-ghost text-foreground/70"
          }`}
        >
          {enabled ? <Lock className="h-3.5 w-3.5" /> : <Unlock className="h-3.5 w-3.5" />}
          {enabled ? "Window active" : "No restriction"}
        </button>
      }
    >
      {enabled && (
        <>
          <div className="flex flex-col gap-3 sm:flex-row sm:items-end">
            <ClayField label="Open from">
              <input type="time" value={openFrom} onChange={(e) => setOpenFrom(e.target.value)} className={inputClass} />
            </ClayField>
            <ClayField label="Open until">
              <input type="time" value={openUntil} onChange={(e) => setOpenUntil(e.target.value)} className={inputClass} />
            </ClayField>
            <button
              onClick={saveWindow}
              disabled={saving}
              className="clay-btn-ghost rounded-full px-4 py-2.5 text-xs font-semibold text-foreground/70 disabled:opacity-70"
            >
              Save window
            </button>
          </div>

          <p className={`mt-3 flex items-center gap-1.5 text-xs font-medium ${isLockedNow ? "text-[var(--destructive)]" : "text-foreground/50"}`}>
            {isLockedNow ? <Lock className="h-3 w-3" /> : <Unlock className="h-3 w-3" />}
            {isLockedNow
              ? "Messaging is currently locked outside your open window."
              : `Messaging is open now (${openFrom}–${openUntil} daily).`}
          </p>
        </>
      )}
    </Panel>
  );
}

// ─── Note uploads — batch-wide or lecture-specific, no watermark ──────────
// The old anti-piracy watermark step is gone entirely — notes are stored
// and served exactly as uploaded. What replaced it: a scope choice at
// upload time. "Whole batch" behaves like before (every purchaser sees
// it); "One lecture" attaches the note to a specific AsyncLecture session,
// so it only shows up alongside that recording rather than in the
// shared batch-wide notes pool.
function NoteUploadGate({ mentorToken, batchId }: { mentorToken: string; batchId: string }) {
  const [fileName, setFileName] = useState("");
  const [fileUrl, setFileUrl] = useState("");
  const [acknowledged, setAcknowledged] = useState(false);
  const [scope, setScope] = useState<"batch" | string>("batch"); // "batch" or a lectureSessionId
  const [lectures, setLectures] = useState<LectureOption[] | null>(null);
  const [notes, setNotes] = useState<Note[] | null>(null);
  const [filter, setFilter] = useState<"all" | "batch-only" | string>("all");
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showForm, setShowForm] = useState(false);

  async function refreshLectures() {
    const { lectures: rows } = await listBatchLecturesForNoteScope({ data: { token: mentorToken, batchId } });
    setLectures(rows);
  }

  async function refreshNotes(currentFilter: typeof filter) {
    const { notes: rows } = await listMentorNotes({
      data: {
        token: mentorToken,
        batchId,
        lectureSessionId: currentFilter === "all" ? undefined : currentFilter,
      },
    });
    setNotes(rows);
  }

  useEffect(() => {
    refreshLectures();
    setFilter("all");
    refreshNotes("all");
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [batchId]);

  useEffect(() => {
    refreshNotes(filter);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [filter]);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);

    if (!fileUrl.trim()) return setError("Upload a PDF first.");
    if (!acknowledged) return setError("You must check the copyright safety toggle before uploading.");

    setSaving(true);
    try {
      await uploadMentorNote({
        data: {
          token: mentorToken,
          batchId,
          fileName: fileName.trim(),
          fileUrl: fileUrl.trim(),
          lectureSessionId: scope === "batch" ? null : scope,
          copyrightAcknowledged: acknowledged,
        },
      });
      setFileName("");
      setFileUrl("");
      setAcknowledged(false);
      setScope("batch");
      setShowForm(false);
      await refreshNotes(filter);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not upload. Try again.");
    } finally {
      setSaving(false);
    }
  }

  const lectureTitleById = new Map((lectures ?? []).map((l) => [l.id, l.lectureTitle]));

  return (
    <Panel
      icon={FileUp}
      title="Notes for this batch"
      action={
        <button
          onClick={() => setShowForm((v) => !v)}
          className="clay-btn-ghost inline-flex items-center gap-1.5 rounded-full px-3.5 py-2 text-xs font-semibold text-foreground/70"
        >
          {showForm ? <X className="h-3.5 w-3.5" /> : <Plus className="h-3.5 w-3.5" />}
          {showForm ? "Cancel" : "Upload note"}
        </button>
      }
    >
      {showForm && (
        <form onSubmit={handleSubmit} className="mb-5 space-y-4 border-b border-foreground/10 pb-5">
          <FileUploadField
            label="Upload PDF"
            value={fileUrl}
            fileName={fileName}
            onChange={(url, name) => {
              setFileUrl(url);
              setFileName((prev) => prev || name);
            }}
            storagePath={`mentor-notes/${batchId}`}
          />

          <ClayField label="Display name" hint="How this shows to students — defaults to the uploaded file's name.">
            <input
              value={fileName}
              onChange={(e) => setFileName(e.target.value)}
              placeholder="e.g. Organic Chemistry Notes — Unit 4"
              className={inputClass}
            />
          </ClayField>

          <ClayField label="Push to" hint="Attach this note to the whole batch, or to just one lecture.">
            <div className="relative">
              <select value={scope} onChange={(e) => setScope(e.target.value)} className={inputClass + " appearance-none pr-10"}>
                <option value="batch">Whole batch (all students)</option>
                {(lectures ?? []).map((l) => (
                  <option key={l.id} value={l.id}>
                    Lecture only — {l.lectureTitle}
                  </option>
                ))}
              </select>
              {scope === "batch" ? (
                <Layers3 className="pointer-events-none absolute right-4 top-1/2 h-4 w-4 -translate-y-1/2 text-foreground/40" />
              ) : (
                <PlayCircle className="pointer-events-none absolute right-4 top-1/2 h-4 w-4 -translate-y-1/2 text-foreground/40" />
              )}
            </div>
          </ClayField>

          <label className="clay-inset flex cursor-pointer items-start gap-3 rounded-2xl px-4 py-3">
            <input
              type="checkbox"
              checked={acknowledged}
              onChange={(e) => setAcknowledged(e.target.checked)}
              className="mt-0.5 h-4 w-4 accent-[var(--sky-deep)]"
            />
            <div className="flex items-start gap-2 text-sm text-foreground">
              <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-foreground/50" />
              <span>I confirm this document is copyright-safe to share with students.</span>
            </div>
          </label>

          {error && <ErrorBanner message={error} />}

          <button
            type="submit"
            disabled={saving || !acknowledged || !fileUrl}
            className="clay-btn flex items-center justify-center gap-2 rounded-full px-6 py-2.5 text-sm font-semibold disabled:opacity-70"
          >
            {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : "Save note"}
          </button>
        </form>
      )}

      <div className="mb-3 flex flex-wrap gap-1.5">
        {[
          { key: "all", label: "All notes" },
          { key: "batch-only", label: "Batch-wide" },
        ].map((f) => (
          <button
            key={f.key}
            onClick={() => setFilter(f.key as typeof filter)}
            className={`rounded-full px-3 py-1.5 text-xs font-semibold transition-colors ${
              filter === f.key ? "clay-btn text-white" : "clay-btn-ghost text-foreground/60"
            }`}
          >
            {f.label}
          </button>
        ))}
        {(lectures ?? []).map((l) => (
          <button
            key={l.id}
            onClick={() => setFilter(l.id)}
            className={`rounded-full px-3 py-1.5 text-xs font-semibold transition-colors ${
              filter === l.id ? "clay-btn text-white" : "clay-btn-ghost text-foreground/60"
            }`}
          >
            {l.lectureTitle}
          </button>
        ))}
      </div>

      {notes === null ? (
        <LoadingBlock compact />
      ) : notes.length === 0 ? (
        <EmptyState icon={FileText} message="No notes uploaded yet." />
      ) : (
        <ul className="space-y-2">
          {notes.map((n) => (
            <li key={n.id} className="clay-inset flex items-center justify-between gap-3 px-4 py-2.5">
              <a href={n.fileUrl} target="_blank" rel="noreferrer" className="flex min-w-0 flex-1 items-center gap-2">
                <FileText className="h-4 w-4 shrink-0 text-foreground/40" />
                <span className="truncate text-sm text-foreground">{n.fileName}</span>
              </a>
              <span className="shrink-0 inline-flex items-center gap-1 rounded-full bg-foreground/5 px-2.5 py-1 text-[10px] font-semibold uppercase tracking-wide text-foreground/50">
                {n.lectureSessionId ? (
                  <>
                    <PlayCircle className="h-3 w-3" />
                    {lectureTitleById.get(n.lectureSessionId) ?? "Lecture"}
                  </>
                ) : (
                  <>
                    <Layers3 className="h-3 w-3" />
                    Whole batch
                  </>
                )}
              </span>
            </li>
          ))}
        </ul>
      )}
    </Panel>
  );
}